# FPS — Godot launcher v1.0.0-alpha42

Alpha34 is a visual redesign of the alpha33 launcher. Launch/runtime/profile logic is preserved.

## New UI

- Application name changed to **FPS**.
- Animated Godot CanvasItem shader background with a subtle tactical grid, blue/red ambient glow, sweep and scanline motion.
- New glass-style header, FPS identity mark and compact EN/RU/version badges.
- Large launch-control hero with dedicated 60 FPS and vanilla 30 FPS actions.
- Four compact live status cards for game, adaptive runtime, private SkuDef and RA3BattleNet.
- Cleaner game-path/language/profile-safety setup panel.
- Runtime and BattleNet services presented as balanced responsive cards.
- Godot Tween hover feedback on interactive buttons.
- Responsive 4/2/1 status grid and 2/1 service/launch grids.
- New FPS application/window icon.

## Preserved behavior

- Manual English/Russian private SkuDef selection.
- CommunityPatch remains optional for launch.
- Adaptive private `NewVanillaFPS.dll` runtime.
- 30 FPS launches without runtime injection.
- The game's own `xinput1_3.dll` is not scanned or replaced.
- Skirmish Guard and RA3BattleNet integration are unchanged.

## Notes

The UI is built from Godot Controls, StyleBoxFlat resources, a CanvasItem shader and Tweens at runtime. It is not a static launcher screenshot.


## Alpha35 — automatic RA3 directory detection

On first launch, or when the saved path is no longer valid, FPS now locates Red Alert 3 automatically. It checks EA/retail registry keys, Windows uninstall records (including many repacks), all Steam libraries for app 17480, and common EA/Origin/Steam/R.G. Mechanics installation folders. A valid previously selected path always wins, and Browse remains available as a fallback. The detected path is persisted in `user://launcher.cfg`.


## Alpha36 — GitHub integration

FPS is now connected to `ARG303/NewVanillaPatch`. On startup it requests the repository `manifest.json`, reports GitHub sync state in the header, detects a newer launcher version, downloads the launcher URL from the manifest, verifies the optional SHA-256, and offers one-click installation/relaunch. If GitHub or the internet is unavailable, game launching remains fully offline and unaffected. The manifest parser supports the existing `launcher` object and both array/object `files` layouts.


## Alpha39 — superseded

Alpha39 used suspended-process import rewriting for private XInput selection. Alpha40 replaces that mechanism with a normal private-copy/proxy launch specifically to avoid Defender false positives.


## Alpha40 — Defender-safe private XInput launch

Alpha39's suspended-process XInput import rewrite was removed completely. It used remote-process memory APIs that can look like malware behavior to Microsoft Defender. Alpha40 no longer contains the alpha39 import-rewrite helper and does not use `ReadProcessMemory`, `WriteProcessMemory`, `VirtualProtectEx`, `VirtualAllocEx`, `CreateRemoteThread` or `NtQueryInformationProcess` in the RA3 launch helper.

Both FPS modes now use an ordinary private game copy under `user://runtime_ready`:

- **30 FPS** — private `ra3_1.12.game` + the user-supplied clean XInput copied beside it as `xinput1_3.dll`.
- **60 FPS** — private `ra3_1.12.game` + `NewVanillaFPS.dll` copied beside it as `xinput1_3.dll`; the same clean XInput is copied as `xinput1_3_original.dll`, which is the backend expected by the FPS proxy. `NewVanillaFPS.ini` is staged beside them.
- No process injection and no PE import rewriting are used for either mode.
- The installed RA3 `xinput1_3.dll` is not read, renamed, replaced or deleted.
- The private SkuDef virtual root, CommunityPatch support, English/Russian selection, Skirmish Guard, GitHub updater and RA3BattleNet start flow are preserved.

The supplied clean XInput remains byte-identical to the upload: SHA-256 `8d540d484ea41e374fd0107d55d253f87ded4ce780d515d8fd59bbe8c98970a7`.


## alpha41 — cursor / loose-resource fix

alpha40 moved the private `ra3_1.12.game` out of the real `Data` directory. RA3 loads several loose resources relative to the executable/current game root; notably the animated mouse cursors are stored under `Data/Data/Cursors`. As a result the game could run normally while the cursor itself was invisible.

alpha41 keeps the private-XInput design but changes the private launch layout to mirror a normal RA3 installation:

- private executable: `runtime_ready/launch30|60/Data/ra3_1.12.game`;
- private XInput/proxy is beside that executable;
- working directory: `runtime_ready/launch30|60`;
- every directory directly under the real RA3 `Data` directory is exposed beside the private executable through NTFS junctions;
- therefore `Data/Data/Cursors` resolves to the real cursor folder without copying or modifying it;
- loose root files from the real `Data` directory (except `.big`, `.game`, and the installed `xinput1_3.dll`) are copied into the private Data view;
- the installed RA3 executable and installed XInput are still not modified.

This also restores the normal path shape for other loose resources such as Movies/language/support folders while retaining the Defender-safe no-injection proxy scheme from alpha40.


## alpha42 — launch recovery + cursor-compatible Data link

alpha42 reverts the risky alpha41 launch geometry. The private `ra3_1.12.game` and private XInput/proxy are again placed directly in an isolated launcher directory, and RA3 uses the real game root as its working directory (the alpha40 behavior that successfully reached the game). The only added resource compatibility layer is a `Data` junction next to the private executable pointing to the real `<RA3>\Data`. This lets resources resolved relative to the private executable see the real Data tree without moving the executable into a fake Data root or changing SkuDef resolution.

The installed `xinput1_3.dll`, `.game`, BIG files and SkuDefs remain unmodified.


## alpha43 cursor path fix

The alpha42 broad private `Data` junction pointed one directory too shallow for RA3's loose cursor assets. RA3 contains literal `data\cursors` file lookups, while retail layouts store the actual `.ani` files under `Data\Data\Cursors`.

alpha43 keeps the alpha42 launch geometry and creates only a targeted compatibility link beside the private executable:

- `launch30_v43\Data\Cursors` -> installed RA3 `Data\Data\Cursors`
- `launch60_v43\Data\Cursors` -> installed RA3 `Data\Data\Cursors`

A flattened `Data\Cursors` layout is accepted as a fallback for repacks. The private SkuDef virtual root is unchanged and still maps its own `Data` to the installed RA3 `Data` directory.
