#!/usr/bin/env python3
from pathlib import Path
import sys

SIG = bytes.fromhex('''
F3 0F 10 40 20 F3 0F 10 48 1C F3 0F 59 4C 24 24
F3 0F 59 54 24 40 0F 28 DD F3 0F 5C D9 0F 28 C8
F3 0F 59 4C 24 28 8B 6C 24 74 0F 28 E5 F3 0F 5C
E1 F3 0F 58 DC F3 0F 58 D8 F3 0F 11 58 20 8B 86
08 02 00 00 F3 0F 10 40 20 F3 0F 58 40 1C F3 0F
11 40 1C 8B 86 08 02 00 00 F3 0F 10 40 28 F3 0F
5C C2 F3 0F 11 40 28 8B 86 08 02 00 00 F3 0F 10
40 28 F3 0F 10 48 24 F3 0F 59 4C 24 2C 0F 28 D5
F3 0F 5C D1 0F 28 C8 F3 0F 59 4C 24 30 0F 28
DD F3 0F 5C D9 F3 0F 58 D3 F3 0F 58 D0 F3 0F 11
50 28 8B 86 08 02 00 00 F3 0F 10 40 28 F3 0F 58
40 24 F3 0F 11 40 24
''')
DELTAS = [0x0A,0x10,0x20,0x44,0x77,0x87,0xA7]
NAMES = ['pitch_K','external','pitch_D','pitch_integrate','roll_K','roll_D','roll_integrate']

def occurrences(data, sig):
    out=[]; start=0
    while True:
        i=data.find(sig,start)
        if i<0: return out
        out.append(i); start=i+1

def version_key(p):
    n=p.name
    import re
    m=re.search(r'ra3_1\.(\d+)',n)
    return int(m.group(1)) if m else 999

def main(folder):
    files=sorted(Path(folder).glob('ra3_1.*.game'), key=version_key)
    if not files:
        raise SystemExit('no ra3_1.*.game files found')
    ok=True
    print('Secondary AttachUpdate parent-bounce spring cross-version audit')
    print(f'signature length: {len(SIG)} bytes')
    for f in files:
        d=f.read_bytes(); hits=occurrences(d,SIG)
        good=len(hits)==1; ok &= good
        if good:
            base=hits[0]
            print(f'{f.name:24} block RVA/raw=0x{base:08X}  unique=YES')
            print('  ' + '  '.join(f'{n}=0x{base+delta:08X}' for n,delta in zip(NAMES,DELTAS)))
        else:
            print(f'{f.name:24} hits={len(hits)}  ERROR')
    return 0 if ok else 1

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit(f'usage: {sys.argv[0]} FOLDER')
    raise SystemExit(main(sys.argv[1]))
