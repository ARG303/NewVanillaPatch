#!/usr/bin/env python3
from pathlib import Path
import struct, sys
ROOT=Path('/mnt/data')
FILES=[ROOT/f'ra3_1.{i}(2).game' for i in range(12)]+[ROOT/'ra3_1.12(6).game']
SIGS={
 'initial_delay_3C': bytes.fromhex('83 C0 FF 89 46 3C 75 13'),
 'emission_delay_104': bytes.fromhex('8B 86 04 01 00 00 85 C0 75 5E 8D 8D A8 00 00 00'),
 'system_lifetime_10C': bytes.fromhex('83 C0 FF 89 86 0C 01 00 00 8B 8E 90 00 00 00'),
}
def hits(d,s):
 out=[]; p=0
 while True:
  i=d.find(s,p)
  if i<0: return out
  out.append(i); p=i+1
ok=True
for p in FILES:
 d=p.read_bytes(); print(p.name)
 for name,sig in SIGS.items():
  h=hits(d,sig); good=len(h)==1; ok &= good
  print(f'  {name:22} count={len(h)}', *(f'RVA=0x{x:08X}' for x in h))
print('RESULT:', 'PASS' if ok else 'FAIL')
raise SystemExit(0 if ok else 1)
