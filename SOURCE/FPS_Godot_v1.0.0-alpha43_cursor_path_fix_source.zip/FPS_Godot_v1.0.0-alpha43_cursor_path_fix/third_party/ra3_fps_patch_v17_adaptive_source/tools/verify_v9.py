#!/usr/bin/env python3
from pathlib import Path
import hashlib, struct, sys

EXPECTED_SHA = '29aa6b66fc298188fa42df7218a1dea7e181a946a54d0d8841000906f9f4d98e'
IMAGE_BASE = 0x400000

def u32(data, off): return struct.unpack_from('<I', data, off)[0]
def i32(data, off): return struct.unpack_from('<i', data, off)[0]
def raw(va): return va - IMAGE_BASE

def main(path):
    data=Path(path).read_bytes()
    sha=hashlib.sha256(data).hexdigest()
    ok=sha==EXPECTED_SHA
    print('sha256:', sha, 'OK' if ok else 'MISMATCH')

    checks = [
        ('phase batch', 0x0065517E, bytes.fromhex('8D4EFF0FAFCFB8ABAAAA2A')),
        ('phase interpolation', 0x0064169C, bytes.fromhex('8D4101F30F2AC0F30F5905')),
        ('scripted-model step', 0x0093115C, bytes.fromhex('F30F58057010BF00')),
        ('GPU particle create', 0x006FFDAA, bytes.fromhex('D80DFC0DCE00')),
        ('GPU particle expiry', 0x0070C0F9, bytes.fromhex('0FAF059C40CB00')),
        ('GameLogic flush queue head', 0x0053A251, bytes.fromhex('8BB7740100003BB778010000')),
    ]
    for name,va,expected in checks:
        actual=data[raw(va):raw(va)+len(expected)]
        good=actual==expected
        ok &= good
        print(f'{name:30} VA=0x{va:08X} {"OK" if good else "MISMATCH"}  {actual.hex(" ")}')

    # The scheduler invokes GameLogic via vtable slot +0x34. Prove the slot is
    # the body whose pending Object->Drawable queue we gate.
    slot_va=0x00BF149C+0x34
    update_phase=u32(data,raw(slot_va))
    good=update_phase==0x00539B20
    ok &= good
    print(f'GameLogic vtable +0x34          VA=0x{slot_va:08X} -> 0x{update_phase:08X} {"OK" if good else "MISMATCH"}')

    call_va=0x0053A264
    call_off=raw(call_va)
    good=data[call_off]==0xE8
    target=call_va+5+i32(data,call_off+1) if good else 0
    good = good and target==0x007DC960
    ok &= good
    print(f'flush queue call target         VA=0x{call_va:08X} -> 0x{target:08X} {"OK" if good else "MISMATCH"}')

    # Show the exact 60-FPS slice-end schedule used by the trampoline.
    ratio=60//15
    ends=[]
    groups=[]
    cur=[]
    for phase in range(1,7):
        slot=(ratio*phase+5)//6
        end=(6*slot)//ratio
        cur.append(phase)
        if phase==end:
            ends.append(phase); groups.append(cur); cur=[]
    print('60-FPS client slices:', groups, 'flush phases:', ends)
    good=(groups==[[1],[2,3],[4],[5,6]] and ends==[1,3,4,6])
    ok &= good
    print('client-slice formula:', 'OK' if good else 'MISMATCH')

    for name,va,want in [('logic_fps',0x00CB4098,15),('render_fps',0x00CB409C,30)]:
        got=u32(data,raw(va)); good=got==want; ok &= good
        print(f'{name:30} VA=0x{va:08X} value={got} {"OK" if good else "MISMATCH"}')

    return 0 if ok else 1

if __name__=='__main__':
    if len(sys.argv)!=2:
        raise SystemExit(f'usage: {sys.argv[0]} ra3_1.12.game')
    raise SystemExit(main(sys.argv[1]))
