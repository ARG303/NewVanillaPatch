#!/usr/bin/env python3
from pathlib import Path
import hashlib, struct, sys

GAME = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/mnt/data/ra3_1.12(3).game')
data = GAME.read_bytes()
EXPECTED_SHA = '29aa6b66fc298188fa42df7218a1dea7e181a946a54d0d8841000906f9f4d98e'
sha = hashlib.sha256(data).hexdigest()
print('sha256', sha, 'OK' if sha == EXPECTED_SHA else 'DIFFERENT')

def u32(o): return struct.unpack_from('<I', data, o)[0]
def b(o,n): return data[o:o+n]
# In this PE, .text/.rdata/.data raw offsets equal RVAs for all sites below.
sites = [
    ('phase batch', 0x25517E, bytes.fromhex('8D4EFF0FAFCFB8ABAAAA2A')),
    ('phase interpolation', 0x24169C, bytes.fromhex('8D4101F30F2AC0F30F5905')),
    ('scripted-model step', 0x53115C, bytes.fromhex('F30F5805')),
    ('client frames/ms init mov', 0x7B40D1, bytes.fromhex('A1')),
    ('client frames/ms init fild', 0x7B40D6, bytes.fromhex('DB05')),
    ('GPU particle create fmul', 0x2FFDAA, bytes.fromhex('D80D')),
    ('GPU particle expiry imul', 0x30C0F9, bytes.fromhex('0FAF05')),
]
ok=True
for name,off,prefix in sites:
    hit=b(off,len(prefix))==prefix
    ok &= hit
    print(f'{name:28s} 0x{off:08X}', 'OK' if hit else 'MISMATCH')

render_va = 0x00CB409C
frames_ms_va = 0x00CE0DFC
print('render_fps value', u32(0x8B409C))
print('init mov operand', hex(u32(0x7B40D2)), 'OK' if u32(0x7B40D2)==render_va else 'BAD')
print('init fild operand', hex(u32(0x7B40D8)), 'OK' if u32(0x7B40D8)==render_va else 'BAD')
print('GPU create operand', hex(u32(0x2FFDAC)), 'OK' if u32(0x2FFDAC)==frames_ms_va else 'BAD')
print('GPU expiry operand', hex(u32(0x30C0FC)), 'OK' if u32(0x30C0FC)==render_va else 'BAD')
for va in (0x735143,0x735181,0x7351C1):
    off=va-0x400000
    good=b(off,2)==bytes.fromhex('D80D') and u32(off+2)==frames_ms_va
    ok &= good
    print(f'StructureUnpack/Sell ref VA 0x{va:08X}', 'OK/live CE0DFC' if good else 'BAD')
raise SystemExit(0 if ok else 1)
