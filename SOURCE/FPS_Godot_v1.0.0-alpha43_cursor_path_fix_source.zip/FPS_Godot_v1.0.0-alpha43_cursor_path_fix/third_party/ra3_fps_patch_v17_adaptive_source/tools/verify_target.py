#!/usr/bin/env python3
from pathlib import Path
import hashlib, struct, sys

PAT = bytes([0xA1,0,0,0,0,0x33,0xD2,0xF7,0x35,0,0,0,0,0x56,0x8B,0xF0,0x83,0xFE,0x06,0x7D,0x14,0xB8,0x06,0,0,0,0x99])
MASK= bytes([1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1])

def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]

def va_to_file(b, va):
    pe=u32(b,0x3c); image_base=u32(b,pe+24+28)
    n=u16(b,pe+6); opt=u16(b,pe+20); st=pe+24+opt
    rva=va-image_base
    for i in range(n):
        off=st+i*40
        name=b[off:off+8].rstrip(b'\0').decode(errors='replace')
        vsz,vaddr,rawsz,raw=struct.unpack_from('<IIII',b,off+8)
        if vaddr <= rva < vaddr+max(vsz,rawsz):
            return name, raw+(rva-vaddr)
    raise ValueError(f'VA {va:#x} not in a section')

def main():
    if len(sys.argv)!=2:
        print('usage: verify_target.py ra3_1.12.game'); return 2
    p=Path(sys.argv[1]); b=p.read_bytes()
    hits=[]
    for i in range(len(b)-len(PAT)+1):
        if all((not m) or b[i+j]==PAT[j] for j,m in enumerate(MASK)):
            hits.append(i)
    print('sha256:', hashlib.sha256(b).hexdigest())
    print('signature hits:', [hex(x) for x in hits])
    if len(hits)!=1: return 1
    i=hits[0]
    render=u32(b,i+1); logic=u32(b,i+9)
    ls,lo=va_to_file(b,logic); rs,ro=va_to_file(b,render)
    lv=u32(b,lo); rv=u32(b,ro)
    print(f'logic_fps : VA={logic:#010x} section={ls} file={lo:#010x} value={lv}')
    print(f'render_fps: VA={render:#010x} section={rs} file={ro:#010x} value={rv}')
    ok=(render==logic+4 and lv==15 and rv==30)
    print('v3 target validation:', 'OK' if ok else 'FAILED')
    return 0 if ok else 1

if __name__=='__main__': raise SystemExit(main())
