/* Build-only stubs used to make a minimal KERNEL32 import library with lld-link.
 * The generated fake DLL is never shipped or loaded. */
void CloseHandle(void) {}
void CreateFileW(void) {}
void DisableThreadLibraryCalls(void) {}
void FlushInstructionCache(void) {}
void GetCurrentProcess(void) {}
void GetModuleFileNameW(void) {}
void GetModuleHandleW(void) {}
void GetProcAddress(void) {}
void GetSystemDirectoryW(void) {}
void InterlockedCompareExchange(void) {}
void InterlockedExchange(void) {}
void LoadLibraryW(void) {}
void OutputDebugStringA(void) {}
void Sleep(void) {}
void VirtualProtect(void) {}
void WriteFile(void) {}
