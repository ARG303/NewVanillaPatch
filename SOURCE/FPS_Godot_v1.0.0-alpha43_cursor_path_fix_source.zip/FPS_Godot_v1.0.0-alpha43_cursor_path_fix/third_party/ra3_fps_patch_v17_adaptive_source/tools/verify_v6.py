#!/usr/bin/env python3
import hashlib, struct, sys
from pathlib import Path

EXPECTED_SHA = '29aa6b66fc298188fa42df7218a1dea7e181a946a54d0d8841000906f9f4d98e'
IMAGE_BASE = 0x400000
SITES = {
    'particle_domain mov': (0x00BB40D1, b'\xA1\x9C\x40\xCB\x00'),
    'particle_domain fild': (0x00BB40D6, b'\xDB\x05\x9C\x40\xCB\x00'),
    'gpu particle expiry fps': (0x0070C0F9, b'\x0F\xAF\x05\x9C\x40\xCB\x00'),
    'scripted model step': (0x0093115C, b'\xF3\x0F\x58\x05\x70\x10\xBF\x00'),
}

def main(path):
    data=Path(path).read_bytes()
    sha=hashlib.sha256(data).hexdigest()
    print('sha256:', sha, 'OK' if sha==EXPECTED_SHA else 'MISMATCH')
    ok=sha==EXPECTED_SHA
    for name,(va,expected) in SITES.items():
        off=va-IMAGE_BASE
        actual=data[off:off+len(expected)]
        good=actual==expected
        ok &= good
        print(f'{name:26} VA=0x{va:08X} bytes={actual.hex(" ")} {"OK" if good else "MISMATCH"}')
    # stock timing globals
    for name,va,want in [('logic_fps',0x00CB4098,15),('render_fps',0x00CB409C,30)]:
        off=va-IMAGE_BASE
        got=struct.unpack_from('<I',data,off)[0]
        good=got==want
        ok &= good
        print(f'{name:26} VA=0x{va:08X} value={got} {"OK" if good else "MISMATCH"}')
    return 0 if ok else 1

if __name__=='__main__':
    if len(sys.argv)!=2:
        raise SystemExit(f'usage: {sys.argv[0]} ra3_1.12.game')
    raise SystemExit(main(sys.argv[1]))
