#!/usr/bin/env python3
from pathlib import Path
import sys

SIG=bytes.fromhex(
    '51 8B 44 24 08 8B 50 04 8B 42 04 '
    'F3 0F 10 88 04 01 00 00 '
    'F3 0F 10 A0 FC 00 00 00 0F 57 C0 '
    'F3 0F 10 90 08 01 00 00 '
    'F3 0F 10 98 00 01 00 00')
AEL=bytes.fromhex('F3 0F 10 48 34')
ELV=bytes.fromhex('F3 0F 58 58 38')

# Offsets from helper start in the retail function body.
AEL_DELTA=0x55
ELV_DELTA=0x90

def all_hits(data, pat):
    out=[]; start=0
    while True:
        i=data.find(pat,start)
        if i<0: return out
        out.append(i); start=i+1

def main(paths):
    print('file\thelper_rva\taeleron_rva\televator_rva\tunique/sites')
    ok=True
    for name in paths:
        d=Path(name).read_bytes()
        hits=all_hits(d,SIG)
        good=len(hits)==1
        if good:
            h=hits[0]
            sites=(d[h+AEL_DELTA:h+AEL_DELTA+len(AEL)]==AEL and
                   d[h+ELV_DELTA:h+ELV_DELTA+len(ELV)]==ELV)
            good &= sites
            print(f'{Path(name).name}\t0x{h:08X}\t0x{h+AEL_DELTA:08X}\t0x{h+ELV_DELTA:08X}\t{good}')
        else:
            print(f'{Path(name).name}\t{hits}\t-\t-\tFalse')
        ok &= good
    return 0 if ok else 1

if __name__=='__main__':
    if len(sys.argv)<2:
        raise SystemExit(f'usage: {sys.argv[0]} ra3_1.0.game ... ra3_1.12.game')
    raise SystemExit(main(sys.argv[1:]))
