#!/usr/bin/env python3
from pathlib import Path
import hashlib, struct, sys

EXPECTED_SHA='29aa6b66fc298188fa42df7218a1dea7e181a946a54d0d8841000906f9f4d98e'
IMAGE_BASE=0x400000

def raw(va): return va-IMAGE_BASE

def u32(d,o): return struct.unpack_from('<I',d,o)[0]

def check(d,name,va,hx):
    expected=bytes.fromhex(hx)
    actual=d[raw(va):raw(va)+len(expected)]
    ok=actual==expected
    print(f'{name:42} VA=0x{va:08X} {"OK" if ok else "MISMATCH"}')
    if not ok:
        print('  expected:', expected.hex(' '))
        print('  actual:  ', actual.hex(' '))
    return ok

def main(path):
    d=Path(path).read_bytes()
    sha=hashlib.sha256(d).hexdigest()
    ok=sha==EXPECTED_SHA
    print('sha256:',sha,'OK' if ok else 'MISMATCH')

    checks=[
      # v15 new systemic locomotor periodic-correction family.
      ('Locomotor correction helper prefix',0x0055BA20,
       '51 8B 44 24 08 8B 50 04 8B 42 04 '
       'F3 0F 10 88 04 01 00 00 '
       'F3 0F 10 A0 FC 00 00 00 0F 57 C0 '
       'F3 0F 10 90 08 01 00 00 '
       'F3 0F 10 98 00 01 00 00'),
      ('Aeleron phase-rate hook site',0x0055BA75,'F3 0F 10 48 34'),
      ('Elevator phase-rate hook site',0x0055BAB0,'F3 0F 58 58 38'),

      # Proven v12 contracts retained by v15.
      ('W3D special advance',0x0063DB2D,'A12865CE0003050C69CE0050A32865CE00'),
      ('W3D normal advance',0x0063DB71,'8B0D0C69CE00A12865CE000FAFCE03C150A32865CE00'),
      ('Anim2D timestamp frame read',0x006F9385,'8B118B427483C410FFD0'),
      ('Anim2D update frame read',0x006F9449,'8B018B5074FFD2'),
      ('Tracer reset frame read',0x0092D06D,'8B118B4274FFD0'),
      ('Tracer update frame read',0x0092D149,'8B018B5074FFD2'),
      ('Cloud effect frame read',0x00617DDC,'8B018B5074FFD2'),
      ('phase batch',0x0065517E,'8D4EFF0FAFCFB8ABAAAA2A'),
      ('phase interpolation',0x0064169C,'8D4101F30F2AC0F30F5905'),
      ('scripted-model step',0x0093115C,'F30F58057010BF00'),
      ('RTS camera step',0x00628AFA,'D9057010BF00'),
      ('GPU particle create',0x006FFDAA,'D80DFC0DCE00'),
      ('GPU particle expiry',0x0070C0F9,'0FAF059C40CB00'),
      ('BounceKick reader',0x00568046,'F30F10818C000000F30F5905340ECE00'),
      ('FX initial-delay raw countdown',0x0070FE1D,'83C0FF89463C7513'),
      ('FX recurring emission scheduler',0x006FD809,'8B860401000085C0755E8D8DA8000000'),
      ('FX system-lifetime raw countdown',0x006F5ED4,'83C0FF89860C0100008B8E90000000'),
      ('FX manager sole caller',0x0063329D,'E8AECF0D00'),
    ]
    for x in checks:
        ok &= check(d,*x)

    for name,va,want in [('logic_fps',0x00CB4098,15),('render_fps',0x00CB409C,30)]:
        got=u32(d,raw(va)); good=got==want; ok &= good
        print(f'{name:42} VA=0x{va:08X} {got} {"OK" if good else "MISMATCH"}')

    print('v15 policy: Elevator/Aeleron phase rate *= 30/targetFPS; Degree unchanged')
    print('v15 policy: complete FXParticleSystemManager simulation runs at authored 30 Hz')
    print('W3D 60-FPS cadence: fixed-point 990/60 -> 16/17 ms sequence')
    print('Synthetic authored frame: selected confirmed consumers only')
    return 0 if ok else 1

if __name__=='__main__':
    if len(sys.argv)!=2:
        raise SystemExit(f'usage: {sys.argv[0]} ra3_1.12.game')
    raise SystemExit(main(sys.argv[1]))
