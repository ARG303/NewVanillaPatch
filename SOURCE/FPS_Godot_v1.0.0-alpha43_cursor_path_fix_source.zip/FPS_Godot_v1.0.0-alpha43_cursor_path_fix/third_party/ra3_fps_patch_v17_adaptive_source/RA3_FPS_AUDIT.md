# v17-adaptive note

This file preserves the v16 behavioral audit used as the patch lineage. v17 changes address discovery to runtime signatures; the behavioral patch domains remain the same.

# Red Alert 3 FPS dependency audit — v16 systemic pass

This report treats the 13 retail binaries (1.0–1.12) as a differential corpus. The goal is to identify stable engine time domains and their consumers, not to replace every numeric 30/33/0.03 occurrence.

## Systemic time domains

| Domain | 1.12 state before patch | Correct 60-FPS policy | Status |
|---|---:|---|---|
| Logic scheduler | 15 Hz, 6 sub-phases | keep 15 Hz; batch 6 phases into 4 client slices | implemented/tested |
| Phase interpolation | stock 30-FPS assumptions | expose one interpolation sample per client slice | implemented/tested |
| Object→Drawable flush | after raw phases | flush at client-slice ends | implemented/tested |
| Continuous visual seconds/frame | 1/30 authored operands | use 1/targetFPS only for proven continuous integrators | camera + scripted model implemented; more consumers under audit |
| Client frames/ms | derived from render FPS | stay live at target FPS (~0.06 at 60) | implemented/tested |
| GPU particle authored frame domain | 30-frame authored | keep creation+expiry consistently at 30 | implemented/tested |
| FXParticleSystem simulation | raw per-client-frame countdowns + module updates without dt | run common FX simulation at authored 30 Hz | **new in v15-systemic** |
| BounceKick Drawable spring | coefficients applied per render frame | integrate with dt=30/target, keep kick amplitude | implemented/tested |
| AttachUpdate parent-bounce response spring | logic-timed discrete BounceAmount impulses feed render-frame pitch/roll spring | keep BounceTimeout/BounceAmount; integrate spring terms with dt=30/target | **new in v16-systemic** |
| Locomotor Elevator/Aeleron periodic correction | `phase += CorrectionRate` once per client frame | scale Rate by 30/target; keep Degree/amplitude | implemented/tested in v15 |
| W3D integer millisecond clock | floor(1000/FPS) | fixed-point 990/target cadence (16/17 ms at 60) | **new in v12-systemic** |
| Absolute frame-authored visuals | raw GameClient frame | selected consumers use synthetic 30-Hz frame | **new in v12-systemic** |
| Generic per-render frame guards | raw GameClient frame | keep raw 60-Hz frame | explicitly not redirected |
| Camera input normalization | mixed | normalize scrollBy/held zoom/height settle/shake by rate | camera step only done; full family still to resolve in RA3 |
| Audio timing | mixed ms/frame + frame consumers | preserve real-time delay | partially auto-correct via early init; call sites still under audit |

## Cross-version proof for newly added families

Each signature below occurs exactly once in every supplied retail binary. File offsets are shown (RVA/raw offset because these builds align .text raw and RVA).

| Version | W3D special | W3D normal | Anim2D set | Anim2D update | Tracer reset | Tracer update | Cloud |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1.0 | 0x1A767D | 0x1A76C1 | 0x263E0B | 0x263ED3 | 0x4EF397 | 0x4EF473 | 0x181916 |
| 1.1 | 0x1A6B0D | 0x1A6B51 | 0x261D3B | 0x261E03 | 0x4ED997 | 0x4EDA73 | 0x180A96 |
| 1.2 | 0x1A79FD | 0x1A7A41 | 0x2628AB | 0x262973 | 0x4ED8B7 | 0x4ED993 | 0x181DB6 |
| 1.3 | 0x1A79FD | 0x1A7A41 | 0x2628AB | 0x262973 | 0x4ED8B7 | 0x4ED993 | 0x181DB6 |
| 1.4 | 0x1A77CD | 0x1A7811 | 0x262AEB | 0x262BB3 | 0x4EDA97 | 0x4EDB73 | 0x181C16 |
| 1.5 | 0x20500D | 0x205051 | 0x2C038B | 0x2C0453 | 0x4F2CF7 | 0x4F2DD3 | 0x1DF196 |
| 1.6 | 0x2050ED | 0x205131 | 0x2BFF0B | 0x2BFFD3 | 0x4F2A47 | 0x4F2B23 | 0x1DF146 |
| 1.7 | 0x20541D | 0x205461 | 0x2BFD6B | 0x2BFE33 | 0x4F2157 | 0x4F2233 | 0x1DF976 |
| 1.8 | 0x204BED | 0x204C31 | 0x2C0B6B | 0x2C0C33 | 0x4F3C17 | 0x4F3CF3 | 0x1DED66 |
| 1.9 | 0x20526D | 0x2052B1 | 0x2C129B | 0x2C1363 | 0x4F4C97 | 0x4F4D73 | 0x1DF186 |
| 1.10 | 0x20526D | 0x2052B1 | 0x2C129B | 0x2C1363 | 0x4F4C97 | 0x4F4D73 | 0x1DF186 |
| 1.11 | 0x1FEDED | 0x1FEE31 | 0x2BAD4B | 0x2BAE13 | 0x4EFDB7 | 0x4EFE93 | 0x1D9376 |
| 1.12 | 0x23DB2D | 0x23DB71 | 0x2F937B | 0x2F9443 | 0x52D067 | 0x52D143 | 0x217DD6 |

## v15/v16 Locomotor periodic-correction proof

The 1.12 helper at `0x0055BA20` reads four contiguous LocomotorTemplate floats and advances two persistent phases once per client frame. The field layout and runtime use identify these as the Elevator/Aeleron Degree/Rate pairs. The important operations are:

- `0x0055BA75`: load Aeleron phase; the following instruction adds `AeleronCorrectionRate`.
- `0x0055BAB0`: add `ElevatorCorrectionRate` to the Elevator phase.
- The resulting phases feed `fsin`/`fcos`; the Degree values are then used as amplitudes.

At 30 FPS the authored rate is applied 30 times per second; at 60 FPS it is applied 60 times per second. v15 therefore multiplies only the two Rate values by `30/targetFPS`.

The exact 46-byte helper prefix occurs once in every supplied retail binary and the two hook sites remain at offsets `+0x55` and `+0x90`:

| Version | Helper RVA | Aeleron site | Elevator site |
|---|---:|---:|---:|
| 1.0 | 0x120170 | 0x1201C5 | 0x120200 |
| 1.1 | 0x11F7C0 | 0x11F815 | 0x11F850 |
| 1.2 | 0x120700 | 0x120755 | 0x120790 |
| 1.3 | 0x120700 | 0x120755 | 0x120790 |
| 1.4 | 0x1206C0 | 0x120715 | 0x120750 |
| 1.5 | 0x1203A0 | 0x1203F5 | 0x120430 |
| 1.6 | 0x1208B0 | 0x120905 | 0x120940 |
| 1.7 | 0x120CB0 | 0x120D05 | 0x120D40 |
| 1.8 | 0x1204A0 | 0x1204F5 | 0x120530 |
| 1.9 | 0x120860 | 0x1208B5 | 0x1208F0 |
| 1.10 | 0x120860 | 0x1208B5 | 0x1208F0 |
| 1.11 | 0x11A290 | 0x11A2E5 | 0x11A320 |
| 1.12 | 0x15BA20 | 0x15BA75 | 0x15BAB0 |

### v16 AttachUpdate correction / v13 reclassification

The v13 experimental hooks around `0x0056879D..0x0056883A` were real
FPS-sensitive spring code but were initially misclassified as naval rocking.
The SHIP appearance follows a different locomotor branch (`0x00567920`), and
v15 correctly fixed naval rocking through the common Elevator/Aeleron phase
helper instead.

A new AttachUpdate trace now proves the purpose of the old spring block:

- `0x0072EC41` loads AttachUpdateModuleData `+0x134` = BounceTimeout.
- `0x0072EC4C` multiplies it by `0x00CE0DF8`.
- `0x00BB4061..0x00BB407B` initializes `0x00CE0DF8` from logic FPS
  `0x00CB4098`, so BounceTimeout is logic-time and already real-time invariant.
- `0x0072EC9A` loads `+0x130` = BounceAmount and calls the parent-bounce helper.
- `0x0055C705` / `0x0055C717` add the pitch/roll components of BounceAmount
  directly to Drawable state `+0x20/+0x28`.
- The spring at `0x00568793..0x00568848` consumes those exact state members.

Therefore v16 restores the seven spring hooks with a corrected classification:
continuous restoring, damping, external forcing and position integration are
scaled by `30/targetFPS`; the discrete BounceAmount impulse is not scaled.

The exact 182-byte block is unique in every supplied retail version:

| Version | block RVA/raw | pitch K | external | pitch D | pitch integrate | roll K | roll D | roll integrate |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 1.0 | 0x12C943 | 0x12C94D | 0x12C953 | 0x12C963 | 0x12C987 | 0x12C9BA | 0x12C9CA | 0x12C9EA |
| 1.1 | 0x12BEF3 | 0x12BEFD | 0x12BF03 | 0x12BF13 | 0x12BF37 | 0x12BF6A | 0x12BF7A | 0x12BF9A |
| 1.2 | 0x12CDD3 | 0x12CDDD | 0x12CDE3 | 0x12CDF3 | 0x12CE17 | 0x12CE4A | 0x12CE5A | 0x12CE7A |
| 1.3 | 0x12CDD3 | 0x12CDDD | 0x12CDE3 | 0x12CDF3 | 0x12CE17 | 0x12CE4A | 0x12CE5A | 0x12CE7A |
| 1.4 | 0x12CDF3 | 0x12CDFD | 0x12CE03 | 0x12CE13 | 0x12CE37 | 0x12CE6A | 0x12CE7A | 0x12CE9A |
| 1.5 | 0x12DDA3 | 0x12DDAD | 0x12DDB3 | 0x12DDC3 | 0x12DDE7 | 0x12DE1A | 0x12DE2A | 0x12DE4A |
| 1.6 | 0x12E2B3 | 0x12E2BD | 0x12E2C3 | 0x12E2D3 | 0x12E2F7 | 0x12E32A | 0x12E33A | 0x12E35A |
| 1.7 | 0x12E683 | 0x12E68D | 0x12E693 | 0x12E6A3 | 0x12E6C7 | 0x12E6FA | 0x12E70A | 0x12E72A |
| 1.8 | 0x12DEF3 | 0x12DEFD | 0x12DF03 | 0x12DF13 | 0x12DF37 | 0x12DF6A | 0x12DF7A | 0x12DF9A |
| 1.9 | 0x12E1F3 | 0x12E1FD | 0x12E203 | 0x12E213 | 0x12E237 | 0x12E26A | 0x12E27A | 0x12E29A |
| 1.10 | 0x12E1F3 | 0x12E1FD | 0x12E203 | 0x12E213 | 0x12E237 | 0x12E26A | 0x12E27A | 0x12E29A |
| 1.11 | 0x127BB3 | 0x127BBD | 0x127BC3 | 0x127BD3 | 0x127BF7 | 0x127C2A | 0x127C3A | 0x127C5A |
| 1.12 | 0x168793 | 0x16879D | 0x1687A3 | 0x1687B3 | 0x1687D7 | 0x16880A | 0x16881A | 0x16883A |

## 1.12 authoritative timing globals

- `0x00CB4098` — logic FPS = 15.
- `0x00CB409C` — render/client FPS = 30 before patch.
- `0x00CE0DF0` — float(client FPS).
- `0x00CE0DF8` — float(logic FPS), initialized from `0x00CB4098`; used by AttachUpdate BounceTimeout conversion.
- `0x00CE0DF4` — audio milliseconds/client-frame (`1000/FPS` float).
- `0x00CE0DFC` — frames/millisecond (`FPS*0.001`), must remain live at 60.
- `0x00CE0ED4` — visual seconds/client-frame (`1/FPS`).
- `0x00CE690C` — W3D integer milliseconds/client-frame.
- `0x00CE6528` — accumulated W3D current time.

## Global `1/30` audit in 1.12

There is one global float `1/30` (`0x00BF1070`) and nine direct executable references. They are **not all timing**.

| Instruction | Classification | Action |
|---|---|---|
| `0x0051E426` | coordinate/grid quantization path | do not patch |
| `0x0051E754` | coordinate/grid quantization path | do not patch |
| `0x0052934A` | coordinate/grid quantization path | do not patch |
| `0x0052CC10` | spatial/math subdivision path | do not patch without stronger proof |
| `0x0052CC6F` | same spatial/math family | do not patch |
| `0x0052CC90` | same spatial/math family | do not patch |
| `0x00628AFA` | continuous RTS camera visual step | `1/60` (already patched) |
| `0x006C75E7` | helper returns clamped integer 1..128; currently looks like subdivision/sample count, not a clock | leave untouched pending symbol/asset mapping |
| `0x0093115C` | scripted-model continuous visual progress | `1/60` (already patched) |

## GameClient frame-number audit

1.12 has dozens of virtual `getFrameNumber()` consumers. Redirecting all of them would be wrong. The confirmed frame-authored family now redirected to a synthetic 30-Hz frame is:
- `Anim2D` timestamp and update (`0x006F9385`, `0x006F9449`).
- `W3DTracerDraw` reset and update (`0x0092D06D`, `0x0092D149`).
- `TheCloudEffectManager` per-frame guard (`0x00617DDC`).
Generic W3D once-per-render guards (for example the W3D update guard around `0x00926460`) deliberately stay on the real 60-Hz frame.

## v15/v16 FXParticleSystem authored-30 proof

The common FX runtime contains three independent raw client-frame countdowns in 1.12:

- `0x0070FE1D`: `system+0x3C--` — initial/start delay.
- `0x006FD809`: `system+0x104--` — recurring emission/burst delay.
- `0x006F5ED4`: `system+0x10C--` — system lifetime.

The constructor paths initialize these values from template-authored ranges/fields.
The post-emission path invokes particle-module update vfuncs without a dt argument.
`FXParticleSystemManager::update` at `0x00710250` has one direct 1.12 call site,
`0x0063329D`, so v16 keeps that subsystem call gated to 30 Hz rather than halving
individual effect XML values or globally changing GameClient frame semantics.

The three instruction signatures each occur exactly once in every supplied retail
binary 1.0–1.12. See `verification_fx_authored_all_versions.txt`.

The pre-existing GPU-particle creation/expiry hooks remain separate because they
convert between live client timing and the particle-authored frame domain.

## Remaining high-priority families

1. **Laser / beam continuous visuals**: W3DLaserDraw uses the generic W3D frame guard at `0x00926460`; that guard must remain raw 60 unless a laser-specific authored increment is proven.
2. **RudderCorrection family**: a neighboring phase exists in locomotor runtime, but its concrete `RudderCorrectionRate` consumer has not yet been proven; do not scale by adjacency alone.
3. **Full camera input normalization**: normalize RMB-drag, edge/keyboard scroll, held zoom, terrain-height settle and shake at their convergence points.
4. **Audio and UI timers**: audit remaining frame reads and ms/frame consumers for real-time invariance.
5. **Residual effect classes outside FXParticleSystem**: classify any remaining accelerated shader/renderer-specific visuals after v16 testing rather than patching effect names.

## What additional game data gives the most leverage

- Exact installed **compiled asset streams/archives for patch 1.12** (`.big`, `.manifest`, `.bin`, `.relo` or extracted XML), especially the streams containing Soviet units, Japan/naval units, FXParticleSystems and GlobalData.
- If already extracted with the Mod SDK: Terror Drone object XML + its Draw/AnimationState/weapon/behavior XML; one affected naval unit XML + its LocomotorTemplate; and XML for one clearly accelerated FX.
- Any PDB/MAP/symbol files, if available, are extremely valuable.
- A short paired 30-FPS vanilla / 60-FPS patched clip of the same Terror Drone cut, same naval idle-on-water and same accelerated FX helps distinguish exact 2× frame-domain errors from smaller W3D-clock drift.
- Build/distribution info (Steam / EA App / Ultimate Collection / other) plus whether any mod alters assets.

The official EA modding-support repository already contains RA3 source XML, schemas and shaders, so vanilla source assets can also be mapped from there. Exact installed compiled streams are mainly useful to prove that the user’s shipped assets match those sources.
