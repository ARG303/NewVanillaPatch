#include "ra3_patch.h"

BOOL WINAPI DllMainCRTStartup(HINSTANCE module, DWORD reason, LPVOID reserved) {
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) {
        g_ra3_self_module = module;
        g_ra3_game_module = (unsigned char *)GetModuleHandleW(NULL);

        /* Install the source render-FPS change and the signature-validated v7
         * scheduler/visual hooks before RA3's own CRT/static initialization. */
        ra3_patch_early_attach();

        DisableThreadLibraryCalls(module);
    }
    return TRUE;
}
