#include "ra3_patch.h"

typedef unsigned long uint32_t;
typedef signed long int32_t;
typedef unsigned long uintptr_t;

#if defined(_MSC_VER)
#  define THISCALL __thiscall
#else
#  define THISCALL __attribute__((thiscall))
#endif

HMODULE g_ra3_self_module = NULL;
unsigned char *g_ra3_game_module = NULL;

/* MSVC-targeted freestanding floating-point code references this marker. */
int _fltused = 0;

/* v17-adaptive keeps the proven v15 ship-rocking and FX domains and adds a
 * second proven render-frame spring: AttachUpdate's ADD_BOUNCE_TO_PARENT
 * impulse feeds Drawable state +0x20/+0x28, whose pitch/roll response is
 * integrated once per client frame. BounceTimeout itself is logic-timed at
 * 15 Hz and BounceAmount is a discrete velocity impulse, so neither is scaled.
 * Only the continuous secondary spring terms use retailFPS/targetFPS. */
#define RA3_TARGET_FPS 60UL
#define RA3_LOGIC_FPS 15UL
#define RA3_RETAIL_VISUAL_FPS 30UL
#define RA3_LOGIC_PHASE_COUNT 6UL

/* Stock 1.12 RVAs are defaults only. v17-adaptive resolves every active patch
 * site from unique machine-code signatures at runtime before writing. */
static uint32_t g_rva_phase_batch_block = 0x0025517EUL; /* VA 0x0065517E, 41 bytes */
#define RVA_PHASE_BATCH_BLOCK g_rva_phase_batch_block
static uint32_t g_rva_phase_interp_block = 0x0024169CUL; /* VA 0x0064169C, 50 bytes */
#define RVA_PHASE_INTERP_BLOCK g_rva_phase_interp_block
static uint32_t g_rva_phase_interp_rejoin = 0x002416CEUL; /* VA 0x006416CE */
#define RVA_PHASE_INTERP_REJOIN g_rva_phase_interp_rejoin
static uint32_t g_rva_client_slice_flush_gate = 0x0013A251UL; /* VA 0x0053A251 */
#define RVA_CLIENT_SLICE_FLUSH_GATE g_rva_client_slice_flush_gate
static uint32_t g_rva_client_slice_flush_cont = 0x0013A257UL; /* original instruction after overwritten MOV */
#define RVA_CLIENT_SLICE_FLUSH_CONT g_rva_client_slice_flush_cont
static uint32_t g_rva_client_slice_flush_skip = 0x0013A2A1UL; /* code immediately after queue drain+clear */
#define RVA_CLIENT_SLICE_FLUSH_SKIP g_rva_client_slice_flush_skip
static uint32_t g_rva_particle_sim_call = 0x0023329DUL; /* VA 0x0063329D */
#define RVA_PARTICLE_SIM_CALL g_rva_particle_sim_call
static uint32_t g_rva_particle_sim_target = 0x00310250UL; /* VA 0x00710250 */
#define RVA_PARTICLE_SIM_TARGET g_rva_particle_sim_target
/* FXParticleSystem is a retail-30 authored simulation domain. These three
 * independent frame countdowns prove that its update cannot safely run at
 * target render FPS without changing effect timing. */
static uint32_t g_rva_fx_initial_delay_dec = 0x0030FE1DUL; /* VA 0x0070FE1D: system+0x3C -- */
#define RVA_FX_INITIAL_DELAY_DEC g_rva_fx_initial_delay_dec
static uint32_t g_rva_fx_emission_countdown = 0x002FD809UL; /* VA 0x006FD809: system+0x104 scheduler */
#define RVA_FX_EMISSION_COUNTDOWN g_rva_fx_emission_countdown
static uint32_t g_rva_fx_system_lifetime_dec = 0x002F5ED4UL; /* VA 0x006F5ED4: system+0x10C -- */
#define RVA_FX_SYSTEM_LIFETIME_DEC g_rva_fx_system_lifetime_dec
static uint32_t g_rva_client_frames_ms_init_mov = 0x007B40D1UL; /* VA 0x00BB40D1: mov eax,[render_fps] */
#define RVA_CLIENT_FRAMES_MS_INIT_MOV g_rva_client_frames_ms_init_mov
static uint32_t g_rva_client_frames_ms_init_fild = 0x007B40D6UL; /* VA 0x00BB40D6: fild [render_fps] */
#define RVA_CLIENT_FRAMES_MS_INIT_FILD g_rva_client_frames_ms_init_fild
static uint32_t g_rva_client_frames_ms_value = 0x008E0DFCUL; /* VA 0x00CE0DFC: live target frames/ms */
#define RVA_CLIENT_FRAMES_MS_VALUE g_rva_client_frames_ms_value
static uint32_t g_rva_gpu_particle_create_fmul = 0x002FFDAAUL; /* VA 0x006FFDAA: FxpsGPUStorageModule.cpp */
#define RVA_GPU_PARTICLE_CREATE_FMUL g_rva_gpu_particle_create_fmul
static uint32_t g_rva_gpu_particle_fps_insn = 0x0030C0F9UL; /* VA 0x0070C0F9: expiry imul eax,[render_fps] */
#define RVA_GPU_PARTICLE_FPS_INSN g_rva_gpu_particle_fps_insn
static uint32_t g_rva_model_step_instruction = 0x0053115CUL; /* VA 0x0093115C */
#define RVA_MODEL_STEP_INSTRUCTION g_rva_model_step_instruction
static uint32_t g_rva_camera_step_instruction = 0x00228AFAUL; /* VA 0x00628AFA: fld [retail 1/30] */
#define RVA_CAMERA_STEP_INSTRUCTION g_rva_camera_step_instruction

/* W3DDisplay_RenderAndPresentFrame clock. */
static uint32_t g_rva_w3d_special_advance = 0x0023DB2DUL; /* VA 0x0063DB2D, 17 bytes */
#define RVA_W3D_SPECIAL_ADVANCE g_rva_w3d_special_advance
static uint32_t g_rva_w3d_normal_advance = 0x0023DB71UL; /* VA 0x0063DB71, 22 bytes */
#define RVA_W3D_NORMAL_ADVANCE g_rva_w3d_normal_advance
static uint32_t g_rva_w3d_accumulated_time_ms = 0x008E6528UL; /* VA 0x00CE6528 */
#define RVA_W3D_ACCUMULATED_TIME_MS g_rva_w3d_accumulated_time_ms
static uint32_t g_rva_w3d_milliseconds_frame = 0x008E690CUL; /* VA 0x00CE690C */
#define RVA_W3D_MILLISECONDS_FRAME g_rva_w3d_milliseconds_frame

/* Proven absolute GameClient frame consumers authored in the retail 30-Hz
 * domain. GameClient::getFrameNumber is vtable slot +0x74 in RA3. */
static uint32_t g_rva_anim2d_timestamp_call = 0x002F9385UL; /* VA 0x006F9385, 10 bytes */
#define RVA_ANIM2D_TIMESTAMP_CALL g_rva_anim2d_timestamp_call
static uint32_t g_rva_anim2d_update_call = 0x002F9449UL; /* VA 0x006F9449, 7 bytes */
#define RVA_ANIM2D_UPDATE_CALL g_rva_anim2d_update_call
static uint32_t g_rva_tracer_reset_call = 0x0052D06DUL; /* VA 0x0092D06D, 7 bytes */
#define RVA_TRACER_RESET_CALL g_rva_tracer_reset_call
static uint32_t g_rva_tracer_update_call = 0x0052D149UL; /* VA 0x0092D149, 7 bytes */
#define RVA_TRACER_UPDATE_CALL g_rva_tracer_update_call
static uint32_t g_rva_cloud_frame_call = 0x00217DDCUL; /* VA 0x00617DDC, 7 bytes */
#define RVA_CLOUD_FRAME_CALL g_rva_cloud_frame_call
static uint32_t g_rva_retail_visual_step = 0x007F1070UL; /* VA 0x00BF1070 = 1/30 */
#define RVA_RETAIL_VISUAL_STEP g_rva_retail_visual_step
static uint32_t g_rva_one_sixth_float = 0x007EF6D0UL; /* VA 0x00BEF6D0 = 1/6 */
#define RVA_ONE_SIXTH_FLOAT g_rva_one_sixth_float

#if RA3_BOUNCE_TIMESTEP_FIX
/* Drawable.cpp / LocomotorTemplate BounceKick pitch+roll spring. */
static uint32_t g_rva_bouncekick_load = 0x00168046UL; /* VA 0x00568046, validation only */
#define RVA_BOUNCEKICK_LOAD g_rva_bouncekick_load
static uint32_t g_rva_bounce_pitch_k_mul = 0x001684A4UL; /* VA 0x005684A4 */
#define RVA_BOUNCE_PITCH_K_MUL g_rva_bounce_pitch_k_mul
static uint32_t g_rva_bounce_pitch_d_mul = 0x001684BCUL; /* VA 0x005684BC */
#define RVA_BOUNCE_PITCH_D_MUL g_rva_bounce_pitch_d_mul
static uint32_t g_rva_bounce_roll_k_mul = 0x001684ECUL; /* VA 0x005684EC */
#define RVA_BOUNCE_ROLL_K_MUL g_rva_bounce_roll_k_mul
static uint32_t g_rva_bounce_roll_d_mul = 0x001684FCUL; /* VA 0x005684FC */
#define RVA_BOUNCE_ROLL_D_MUL g_rva_bounce_roll_d_mul
static uint32_t g_rva_bounce_pitch_integrate = 0x0016851FUL; /* VA 0x0056851F, 17 bytes */
#define RVA_BOUNCE_PITCH_INTEGRATE g_rva_bounce_pitch_integrate
static uint32_t g_rva_bounce_roll_integrate = 0x0016853BUL; /* VA 0x0056853B, 14 bytes */
#define RVA_BOUNCE_ROLL_INTEGRATE g_rva_bounce_roll_integrate

/* Secondary Drawable parent-bounce/attachment attitude spring. AttachUpdate
 * with ADD_BOUNCE_TO_PARENT injects BounceAmount into state +0x20/+0x28; this
 * spring then consumes that state once per client/render frame. */
static uint32_t g_rva_attach_spring_pitch_k_mul = 0x0016879DUL; /* VA 0x0056879D */
#define RVA_ATTACH_SPRING_PITCH_K_MUL g_rva_attach_spring_pitch_k_mul
static uint32_t g_rva_attach_spring_external_force = 0x001687A3UL; /* VA 0x005687A3 */
#define RVA_ATTACH_SPRING_EXTERNAL_FORCE g_rva_attach_spring_external_force
static uint32_t g_rva_attach_spring_pitch_d_mul = 0x001687B3UL; /* VA 0x005687B3 */
#define RVA_ATTACH_SPRING_PITCH_D_MUL g_rva_attach_spring_pitch_d_mul
static uint32_t g_rva_attach_spring_pitch_integrate = 0x001687D7UL; /* VA 0x005687D7, 10 bytes */
#define RVA_ATTACH_SPRING_PITCH_INTEGRATE g_rva_attach_spring_pitch_integrate
static uint32_t g_rva_attach_spring_roll_k_mul = 0x0016880AUL; /* VA 0x0056880A */
#define RVA_ATTACH_SPRING_ROLL_K_MUL g_rva_attach_spring_roll_k_mul
static uint32_t g_rva_attach_spring_roll_d_mul = 0x0016881AUL; /* VA 0x0056881A */
#define RVA_ATTACH_SPRING_ROLL_D_MUL g_rva_attach_spring_roll_d_mul
static uint32_t g_rva_attach_spring_roll_integrate = 0x0016883AUL; /* VA 0x0056883A, 10 bytes */
#define RVA_ATTACH_SPRING_ROLL_INTEGRATE g_rva_attach_spring_roll_integrate

#endif

/* Generic LocomotorTemplate periodic visual correction helper (VA 0x0055BA20).
 * Patch only phase-rate consumption, never Degree/amplitude. */
static uint32_t g_rva_loco_correction_helper = 0x0015BA20UL; /* validation signature */
#define RVA_LOCO_CORRECTION_HELPER g_rva_loco_correction_helper
static uint32_t g_rva_aeleron_phase_load = 0x0015BA75UL; /* movss xmm1,[eax+0x34] */
#define RVA_AELERON_PHASE_LOAD g_rva_aeleron_phase_load
static uint32_t g_rva_elevator_phase_add = 0x0015BAB0UL; /* addss xmm3,[eax+0x38] */
#define RVA_ELEVATOR_PHASE_ADD g_rva_elevator_phase_add

#define ENGINE_CURRENT_LOGIC_PHASE       0x58UL
#define ENGINE_CLIENT_LOGIC_RATIO        0x5CUL
#define ENGINE_LOGIC_PHASE_INTERPOLATION 0x60UL

enum Ra3EarlyStatus {
    RA3_EARLY_NOT_RUN = 0,
    RA3_EARLY_OK = 1,
    RA3_EARLY_BAD_PE = -1,
    RA3_EARLY_SIG_NOT_UNIQUE = -2,
    RA3_EARLY_BAD_POINTERS = -3,
    RA3_EARLY_BAD_SEMANTICS = -4,
    RA3_EARLY_UNEXPECTED_RENDER = -5,
    RA3_EARLY_CODE_MISMATCH = -6,
    RA3_EARLY_WRITE_FAILED = -7,
    RA3_EARLY_ROLLBACK_FAILED = -8
};

static volatile LONG g_early_status = RA3_EARLY_NOT_RUN;
static volatile LONG g_report_state = 0;
static uint32_t g_logic_va = 0;
static uint32_t g_render_va = 0;
static uint32_t g_logic_before = 0;
static uint32_t g_render_before = 0;
static uint32_t g_render_after = 0;
static volatile LONG g_scheduler_batch_installed = 0;
static volatile LONG g_scheduler_interp_installed = 0;
static volatile LONG g_client_slice_flush_installed = 0;
static volatile LONG g_model_step_installed = 0;
static volatile LONG g_camera_step_installed = 0;
static volatile LONG g_particle_gate_installed = 0;
static volatile LONG g_particle_domain_installed = 0;
static volatile LONG g_bounce_timestep_installed = 0;
static volatile LONG g_loco_correction_installed = 0;
static volatile LONG g_w3d_clock_installed = 0;
static volatile LONG g_frame_authored_installed = 0;

/* Process-lifetime replacement operand, analogous to cnc3_fps_patch's
 * g_visual_client_step. v12 redirects both the scripted-model and RTS camera
 * continuous-step operands here. */
static float g_visual_client_step = 1.0f / (float)RA3_TARGET_FPS;
/* Stable absolute operand target used by x86 instructions that must remain in
 * the retail particle/frame-authored domain even after render_fps becomes 60. */
static uint32_t g_retail_visual_fps_storage = RA3_RETAIL_VISUAL_FPS;
static float g_retail_frames_per_millisecond = 0.03f;

/* W3D retail advances 30 * 33 = 990 integer milliseconds per nominal second.
 * Keep the fractional remainder in numerator units (W3D-ms * targetFPS). */
#define RA3_W3D_RETAIL_MS_PER_SECOND 990UL
static volatile uint32_t g_w3d_time_remainder = 0;
static volatile uint32_t g_w3d_last_accumulated = 0;
#ifndef RA3_PARTICLE_GATE
#define RA3_PARTICLE_GATE 1
#endif
#ifndef RA3_CLIENT_SLICE_FLUSH
#define RA3_CLIENT_SLICE_FLUSH 1
#endif
#ifndef RA3_BOUNCE_TIMESTEP_FIX
#define RA3_BOUNCE_TIMESTEP_FIX 1
#endif

/* Original spring coefficients are authored as one 30-FPS visual step. */
#if RA3_BOUNCE_TIMESTEP_FIX
static float g_bounce_visual_dt =
    (float)RA3_RETAIL_VISUAL_FPS / (float)RA3_TARGET_FPS;
#endif

/* Elevator/Aeleron CorrectionRate is authored per retail visual frame. */
static float g_loco_correction_dt =
    (float)RA3_RETAIL_VISUAL_FPS / (float)RA3_TARGET_FPS;

#if RA3_CLIENT_SLICE_FLUSH
static uintptr_t g_flush_continue_addr = 0;
static uintptr_t g_flush_skip_addr = 0;
#endif

/* Start one half-step ahead so a 60->30 gate updates on the first client frame,
 * matching the reset-state behavior of the upstream C&C3/KW patch. */
#if RA3_PARTICLE_GATE
static volatile uint32_t g_particle_update_accumulator =
    (RA3_TARGET_FPS > RA3_RETAIL_VISUAL_FPS)
        ? (RA3_TARGET_FPS - RA3_RETAIL_VISUAL_FPS) : 0;

typedef void (THISCALL *SubsystemUpdateFn)(void *subsystem);
static SubsystemUpdateFn g_original_particle_update = NULL;
#endif

/* Unique in the supplied ra3_1.12.game:
 *   mov eax,[render_fps]; xor edx,edx; div [logic_fps]; ... */
static const unsigned char g_rate_signature[] = {
    0xA1, 0, 0, 0, 0,
    0x33, 0xD2, 0xF7, 0x35, 0, 0, 0, 0,
    0x56, 0x8B, 0xF0, 0x83, 0xFE, 0x06, 0x7D, 0x14,
    0xB8, 0x06, 0x00, 0x00, 0x00, 0x99
};
static const unsigned char g_rate_mask[] = {
    1,0,0,0,0,
    1,1,1,1,0,0,0,0,
    1,1,1,1,1,1,1,1,
    1,1,1,1,1,1
};

/* Exact original bytes from the supplied binary. The interpolation block has
 * one relocated absolute operand; that field is checked separately. */
static const unsigned char g_batch_expected[41] = {
    0x8D,0x4E,0xFF,0x0F,0xAF,0xCF,0xB8,0xAB,0xAA,0xAA,0x2A,0xF7,0xE9,
    0x8B,0xCA,0xC1,0xE9,0x1F,0x8D,0x44,0x0A,0x01,0x8D,0x04,0x40,0x03,
    0xC0,0x99,0xF7,0xFF,0xBB,0x01,0x00,0x00,0x00,0x03,0xF3,0x8B,0xF8,
    0x03,0xFB
};
static const unsigned char g_interp_expected[50] = {
    0x8D,0x41,0x01,0xF3,0x0F,0x2A,0xC0,0xF3,0x0F,0x59,0x05,
    0xD0,0xF6,0xBE,0x00, /* relocated 1/6 pointer; bytes 11..14 masked */
    0x0F,0x2F,0xC8,0x89,0x46,0x58,0xF3,0x0F,0x11,0x46,0x60,0x76,0x05,
    0x0F,0x28,0xC1,0xEB,0x08,0x0F,0x2F,0xC2,0x76,0x03,0x0F,0x28,0xC2,
    0x83,0xF8,0x06,0x57,0xF3,0x0F,0x11,0x46,0x60
};
#if RA3_CLIENT_SLICE_FLUSH
/* Start of GameLogic::UpdatePhase's pending Object-to-Drawable queue drain.
 * The first instruction loads vector.begin; the second compares vector.end.
 * v9 replaces only the first five bytes with a JMP and emulates the complete
 * six-byte MOV in the trampoline on slice-end phases. */
static const unsigned char g_flush_expected[12] = {
    0x8B,0xB7,0x74,0x01,0x00,0x00, /* mov esi,[edi+0x174] */
    0x3B,0xB7,0x78,0x01,0x00,0x00  /* cmp esi,[edi+0x178] */
};
#endif

#if RA3_BOUNCE_TIMESTEP_FIX
/* Prove the exact LocomotorTemplate field reader and all six spring sites
 * before installing any BounceKick-related hook. */
static const unsigned char g_bouncekick_load_expected[16] = {
    0xF3,0x0F,0x10,0x81,0x8C,0x00,0x00,0x00,
    0xF3,0x0F,0x59,0x05,0x34,0x0E,0xCE,0x00
};
static const unsigned char g_bounce_pitch_k_expected[6] = {0xF3,0x0F,0x59,0x54,0x24,0x24};
static const unsigned char g_bounce_pitch_d_expected[6] = {0xF3,0x0F,0x59,0x54,0x24,0x28};
static const unsigned char g_bounce_roll_k_expected[6]  = {0xF3,0x0F,0x59,0x54,0x24,0x2C};
static const unsigned char g_bounce_roll_d_expected[6]  = {0xF3,0x0F,0x59,0x54,0x24,0x30};
static const unsigned char g_bounce_pitch_integrate_expected[17] = {
    0xF3,0x0F,0x10,0x48,0x08,0x0F,0x57,0xDB,0xF3,0x0F,0x59,0xC8,0xF3,0x0F,0x58,0x48,0x04
};
static const unsigned char g_bounce_roll_integrate_expected[14] = {
    0xF3,0x0F,0x10,0x48,0x14,0xF3,0x0F,0x59,0xC8,0xF3,0x0F,0x58,0x48,0x10
};
/* AttachUpdate parent-bounce response spring. */
static const unsigned char g_attach_pitch_k_expected[6] = {0xF3,0x0F,0x59,0x4C,0x24,0x24};
static const unsigned char g_attach_external_expected[6] = {0xF3,0x0F,0x59,0x54,0x24,0x40};
static const unsigned char g_attach_pitch_d_expected[6] = {0xF3,0x0F,0x59,0x4C,0x24,0x28};
static const unsigned char g_attach_pitch_integrate_expected[10] = {0xF3,0x0F,0x10,0x40,0x20,0xF3,0x0F,0x58,0x40,0x1C};
static const unsigned char g_attach_roll_k_expected[6] = {0xF3,0x0F,0x59,0x4C,0x24,0x2C};
static const unsigned char g_attach_roll_d_expected[6] = {0xF3,0x0F,0x59,0x4C,0x24,0x30};
static const unsigned char g_attach_roll_integrate_expected[10] = {0xF3,0x0F,0x10,0x40,0x28,0xF3,0x0F,0x58,0x40,0x24};
#endif

/* Exact body prefix and two hook sites for the generic Locomotor correction
 * helper. The 46-byte prefix is identical and unique in every supplied retail
 * binary 1.0..1.12; 1.12 is the runtime target of this DLL. */
static const unsigned char g_loco_correction_helper_expected[46] = {
    0x51,0x8B,0x44,0x24,0x08,0x8B,0x50,0x04,0x8B,0x42,0x04,
    0xF3,0x0F,0x10,0x88,0x04,0x01,0x00,0x00,
    0xF3,0x0F,0x10,0xA0,0xFC,0x00,0x00,0x00,0x0F,0x57,0xC0,
    0xF3,0x0F,0x10,0x90,0x08,0x01,0x00,0x00,
    0xF3,0x0F,0x10,0x98,0x00,0x01,0x00,0x00
};
static const unsigned char g_aeleron_phase_load_expected[5] = {0xF3,0x0F,0x10,0x48,0x34};
static const unsigned char g_elevator_phase_add_expected[5] = {0xF3,0x0F,0x58,0x58,0x38};

/* Systemic v12 exact code contracts. */
static const unsigned char g_anim2d_timestamp_expected[10] = {
    0x8B,0x11,0x8B,0x42,0x74,0x83,0xC4,0x10,0xFF,0xD0
};
static const unsigned char g_frame_call_expected[7] = {0x8B,0x01,0x8B,0x50,0x74,0xFF,0xD2};
static const unsigned char g_tracer_reset_expected[7] = {0x8B,0x11,0x8B,0x42,0x74,0xFF,0xD0};

typedef struct Ra3PeInfo {
    DWORD size_of_image;
    WORD section_count;
    unsigned char *section_table;
} Ra3PeInfo;

static WORD read_u16(const unsigned char *p) {
    return (WORD)((WORD)p[0] | ((WORD)p[1] << 8));
}
static DWORD read_u32(const unsigned char *p) {
    return (DWORD)p[0] | ((DWORD)p[1] << 8) | ((DWORD)p[2] << 16) | ((DWORD)p[3] << 24);
}
static void encode_u32(unsigned char *p, uint32_t v) {
    p[0]=(unsigned char)v; p[1]=(unsigned char)(v>>8); p[2]=(unsigned char)(v>>16); p[3]=(unsigned char)(v>>24);
}
static void copy_bytes(unsigned char *dst, const unsigned char *src, SIZE_T n) {
    SIZE_T i; for (i=0;i<n;++i) dst[i]=src[i];
}
static void fill_bytes(unsigned char *dst, unsigned char value, SIZE_T n) {
    SIZE_T i; for (i=0;i<n;++i) dst[i]=value;
}
static BOOL equal_bytes(const unsigned char *a, const unsigned char *b, SIZE_T n) {
    SIZE_T i; for (i=0;i<n;++i) if (a[i]!=b[i]) return FALSE; return TRUE;
}

static BOOL valid_pe32(unsigned char *module, Ra3PeInfo *out) {
    DWORD pe_off; unsigned char *nt; WORD opt_size;
    if (!module || !out) return FALSE;
    if (read_u16(module) != 0x5A4D) return FALSE;
    pe_off = read_u32(module + 0x3C);
    if (pe_off == 0 || pe_off > 0x100000) return FALSE;
    nt = module + pe_off;
    if (read_u32(nt) != 0x00004550UL) return FALSE;
    if (read_u16(nt + 4) != 0x014C) return FALSE;
    opt_size = read_u16(nt + 20);
    if (opt_size < 60 || read_u16(nt + 24) != 0x010B) return FALSE;
    out->section_count = read_u16(nt + 6);
    out->size_of_image = read_u32(nt + 24 + 56);
    out->section_table = nt + 24 + opt_size;
    return out->section_count != 0 && out->size_of_image != 0;
}

static BOOL rate_bytes_match(const unsigned char *p) {
    SIZE_T i;
    for (i=0;i<sizeof(g_rate_signature);++i)
        if (g_rate_mask[i] && p[i] != g_rate_signature[i]) return FALSE;
    return TRUE;
}
static BOOL find_rate_signature(unsigned char *module, const Ra3PeInfo *pe, unsigned char **out_match) {
    WORD s; unsigned char *found=NULL; unsigned matches=0;
    for (s=0;s<pe->section_count;++s) {
        const unsigned char *sec=pe->section_table+(DWORD)s*40UL;
        DWORD i,size=read_u32(sec+8),va=read_u32(sec+12),ch=read_u32(sec+36);
        unsigned char *start;
        if ((ch & 0x20000000UL)==0) continue;
        if (size<sizeof(g_rate_signature)||va>=pe->size_of_image||size>pe->size_of_image-va) continue;
        start=module+va;
        for(i=0;i<=size-sizeof(g_rate_signature);++i) if(rate_bytes_match(start+i)) {
            found=start+i; ++matches; if(matches>1) return FALSE;
        }
    }
    if(matches!=1) return FALSE; *out_match=found; return TRUE;
}
static BOOL masked_bytes_match(const unsigned char *p,const unsigned char *pat,const unsigned char *mask,SIZE_T n) {
    SIZE_T i; for(i=0;i<n;++i) if(mask[i] && p[i]!=pat[i]) return FALSE; return TRUE;
}
static BOOL find_unique_exec_masked(unsigned char *module,const Ra3PeInfo *pe,
                                    const unsigned char *pat,const unsigned char *mask,SIZE_T n,
                                    unsigned char **out_match) {
    WORD s; unsigned char *found=NULL; unsigned matches=0;
    if(!module||!pe||!pat||!mask||!out_match||n==0) return FALSE;
    for(s=0;s<pe->section_count;++s) {
        const unsigned char *sec=pe->section_table+(DWORD)s*40UL;
        DWORD i,size=read_u32(sec+8),va=read_u32(sec+12),ch=read_u32(sec+36);
        unsigned char *start;
        if((ch&0x20000000UL)==0) continue;
        if(size<n||va>=pe->size_of_image||size>pe->size_of_image-va) continue;
        start=module+va;
        for(i=0;i<=size-n;++i) if(masked_bytes_match(start+i,pat,mask,n)) {
            found=start+i; ++matches; if(matches>1) return FALSE;
        }
    }
    if(matches!=1) return FALSE; *out_match=found; return TRUE;
}
static BOOL find_unique_exec_exact(unsigned char *module,const Ra3PeInfo *pe,
                                   const unsigned char *pat,SIZE_T n,unsigned char **out_match) {
    unsigned char mask[64]; SIZE_T i;
    if(n>sizeof(mask)) return FALSE;
    for(i=0;i<n;++i) mask[i]=1;
    return find_unique_exec_masked(module,pe,pat,mask,n,out_match);
}
static BOOL absolute_to_rva(unsigned char *module,DWORD image_size,uint32_t abs,uint32_t *out_rva) {
    uintptr_t b=(uintptr_t)module,x=(uintptr_t)abs;
    if(x<b || x-b>=image_size) return FALSE;
    *out_rva=(uint32_t)(x-b); return TRUE;
}
static BOOL find_unique_call_to(unsigned char *module,const Ra3PeInfo *pe,unsigned char *target,unsigned char **out_call) {
    WORD s; unsigned matches=0; unsigned char *found=NULL;
    for(s=0;s<pe->section_count;++s) {
        const unsigned char *sec=pe->section_table+(DWORD)s*40UL;
        DWORD i,size=read_u32(sec+8),va=read_u32(sec+12),ch=read_u32(sec+36);
        unsigned char *start;
        if((ch&0x20000000UL)==0 || size<5 || va>=pe->size_of_image || size>pe->size_of_image-va) continue;
        start=module+va;
        for(i=0;i<=size-5;++i) if(start[i]==0xE8) {
            int32_t rel=(int32_t)read_u32(start+i+1);
            if(start+i+5+rel==target) { found=start+i; ++matches; if(matches>1) return FALSE; }
        }
    }
    if(matches!=1) return FALSE; *out_call=found; return TRUE;
}
static BOOL find_unique_exec_bytes(unsigned char *module,const Ra3PeInfo *pe,const unsigned char *pat,SIZE_T n,unsigned char **out_match) {
    return find_unique_exec_exact(module,pe,pat,n,out_match);
}

static BOOL ptr_inside_image(unsigned char *base, DWORD size, const void *p, SIZE_T need) {
    uintptr_t b=(uintptr_t)base,x=(uintptr_t)p;
    if(x<b) return FALSE; if(x-b>size) return FALSE;
    if(need>size-(DWORD)(x-b)) return FALSE; return TRUE;
}

static BOOL write_memory(void *dst, const void *src, SIZE_T size, BOOL executable) {
    DWORD old_protect, ignored;
    DWORD desired = executable ? PAGE_EXECUTE_READWRITE : PAGE_READWRITE;
    if (!VirtualProtect(dst,size,desired,&old_protect)) return FALSE;
    copy_bytes((unsigned char*)dst,(const unsigned char*)src,size);
    if (executable) FlushInstructionCache(GetCurrentProcess(),dst,size);
    if (!VirtualProtect(dst,size,old_protect,&ignored)) return FALSE;
    return TRUE;
}
static BOOL write_u32(void *dst, uint32_t value, BOOL executable) {
    unsigned char b[4]; encode_u32(b,value); return write_memory(dst,b,4,executable);
}
static void encode_rel32(unsigned char *field, const unsigned char *next_instruction, const void *target) {
    int32_t rel = (int32_t)((const unsigned char*)target - next_instruction);
    encode_u32(field,(uint32_t)rel);
}

/* Port of cnc3_fps_patch's corrected six-phase scheduler batching. In RA3 at
 * 60 FPS the stock ratio=4 path dispatches the six phases across six client
 * frames; this maps them into four slices instead. */
static uint32_t WINAPI get_phase_batch_limit(uint32_t phase, uint32_t ratio) {
    uint32_t client_slot;
    if (ratio == 0) return phase + 1UL;
    client_slot = (ratio * phase + RA3_LOGIC_PHASE_COUNT - 1UL) / RA3_LOGIC_PHASE_COUNT;
    return (RA3_LOGIC_PHASE_COUNT * client_slot) / ratio + 1UL;
}

/* RA3's corresponding interpolation logic is embedded in a larger function.
 * Preserve its phase increment but expose interpolation once per client slice,
 * matching the upstream patch's rule for ratio 4. */
static uint32_t WINAPI update_phase_interpolation_v4(unsigned char *engine, uint32_t current_phase) {
    uint32_t phase = current_phase + 1UL;
    uint32_t ratio = RA3_TARGET_FPS / RA3_LOGIC_FPS;
    uint32_t client_slot;
    float interpolation;
    client_slot = (ratio * phase + RA3_LOGIC_PHASE_COUNT - 1UL) / RA3_LOGIC_PHASE_COUNT;
    if (ratio == 3UL || ratio == 6UL)
        interpolation = (float)phase / (float)RA3_LOGIC_PHASE_COUNT;
    else
        interpolation = (float)client_slot / (float)ratio;
    if (interpolation < 0.0f) interpolation = 0.0f;
    if (interpolation > 1.0f) interpolation = 1.0f;
    *(uint32_t *)(engine + ENGINE_CURRENT_LOGIC_PHASE) = phase;
    *(float *)(engine + ENGINE_LOGIC_PHASE_INTERPOLATION) = interpolation;
    return phase;
}

#if RA3_CLIENT_SLICE_FLUSH
/* At the patch site GameLogic::UpdatePhase has a stable 0x2C-byte local frame
 * and accesses the current phase as [esp+0x40] immediately before/after this
 * queue. At 60 FPS the corrected scheduler maps phases into client slices:
 *   [1], [2,3], [4], [5,6]
 * so phases 2 and 5 are interior phases. Leave the queue intact there and
 * drain+clear it only at phases 1,3,4,6. This mirrors cnc3_fps_patch's
 * is_client_slice_end() scheduler companion without disturbing any Drawable
 * update code itself. */
__declspec(naked) static void client_slice_flush_gate_trampoline(void) {
    __asm {
        mov eax, dword ptr [esp+0x40]
        cmp eax, 2
        je skip_flush
        cmp eax, 5
        je skip_flush

        /* Reproduce the complete six-byte instruction overwritten by the JMP. */
        mov esi, dword ptr [edi+0x174]
        mov eax, dword ptr [g_flush_continue_addr]
        jmp eax

    skip_flush:
        mov eax, dword ptr [g_flush_skip_addr]
        jmp eax
    }
}
#endif

#if RA3_BOUNCE_TIMESTEP_FIX
/* CALL-based stubs preserve the original register contract. A CALL adds four
 * bytes to ESP, so each original stack operand is read at offset +4 here. */
__declspec(naked) static void bounce_pitch_k_step(void) {
    __asm {
        mulss xmm2, dword ptr [esp+0x28]
        mulss xmm2, dword ptr [g_bounce_visual_dt]
        ret
    }
}
__declspec(naked) static void bounce_pitch_d_step(void) {
    __asm {
        mulss xmm2, dword ptr [esp+0x2C]
        mulss xmm2, dword ptr [g_bounce_visual_dt]
        ret
    }
}
__declspec(naked) static void bounce_roll_k_step(void) {
    __asm {
        mulss xmm2, dword ptr [esp+0x30]
        mulss xmm2, dword ptr [g_bounce_visual_dt]
        ret
    }
}
__declspec(naked) static void bounce_roll_d_step(void) {
    __asm {
        mulss xmm2, dword ptr [esp+0x34]
        mulss xmm2, dword ptr [g_bounce_visual_dt]
        ret
    }
}
__declspec(naked) static void bounce_pitch_integrate_step(void) {
    __asm {
        movss xmm1, dword ptr [eax+0x08]
        xorps xmm3, xmm3
        mulss xmm1, xmm0
        mulss xmm1, dword ptr [g_bounce_visual_dt]
        addss xmm1, dword ptr [eax+0x04]
        ret
    }
}
__declspec(naked) static void bounce_roll_integrate_step(void) {
    __asm {
        movss xmm1, dword ptr [eax+0x14]
        mulss xmm1, xmm0
        mulss xmm1, dword ptr [g_bounce_visual_dt]
        addss xmm1, dword ptr [eax+0x10]
        ret
    }
}

/* Secondary spring used by AttachUpdate ADD_BOUNCE_TO_PARENT. CALL shifts
 * original stack operands by +4. BounceAmount itself is intentionally NOT
 * scaled: it is a discrete impulse emitted by the 15-Hz logic-side timeout. */
__declspec(naked) static void attach_pitch_k_step(void) {
    __asm {
        mulss xmm1, dword ptr [esp+0x28]
        mulss xmm1, dword ptr [g_bounce_visual_dt]
        ret
    }
}
__declspec(naked) static void attach_external_step(void) {
    __asm {
        mulss xmm2, dword ptr [esp+0x44]
        mulss xmm2, dword ptr [g_bounce_visual_dt]
        ret
    }
}
__declspec(naked) static void attach_pitch_d_step(void) {
    __asm {
        mulss xmm1, dword ptr [esp+0x2C]
        mulss xmm1, dword ptr [g_bounce_visual_dt]
        ret
    }
}
__declspec(naked) static void attach_pitch_integrate_step(void) {
    __asm {
        movss xmm0, dword ptr [eax+0x20]
        mulss xmm0, dword ptr [g_bounce_visual_dt]
        addss xmm0, dword ptr [eax+0x1C]
        ret
    }
}
__declspec(naked) static void attach_roll_k_step(void) {
    __asm {
        mulss xmm1, dword ptr [esp+0x30]
        mulss xmm1, dword ptr [g_bounce_visual_dt]
        ret
    }
}
__declspec(naked) static void attach_roll_d_step(void) {
    __asm {
        mulss xmm1, dword ptr [esp+0x34]
        mulss xmm1, dword ptr [g_bounce_visual_dt]
        ret
    }
}
__declspec(naked) static void attach_roll_integrate_step(void) {
    __asm {
        movss xmm0, dword ptr [eax+0x28]
        mulss xmm0, dword ptr [g_bounce_visual_dt]
        addss xmm0, dword ptr [eax+0x24]
        ret
    }
}
#endif

/* The helper loads AeleronCorrectionRate in XMM2 and ElevatorCorrectionRate in
 * XMM3. These CALL stubs preserve the original instruction at each site while
 * scaling only the per-frame phase increment. */
__declspec(naked) static void aeleron_phase_rate_step(void) {
    __asm {
        movss xmm1, dword ptr [eax+0x34]
        mulss xmm2, dword ptr [g_loco_correction_dt]
        ret
    }
}
__declspec(naked) static void elevator_phase_rate_step(void) {
    __asm {
        mulss xmm3, dword ptr [g_loco_correction_dt]
        addss xmm3, dword ptr [eax+0x38]
        ret
    }
}

#if RA3_PARTICLE_GATE
/* Gate the complete FXParticleSystemManager simulation to its retail-authored
 * 30-Hz rate. This is not a per-effect workaround: FXParticleSystem contains
 * independent raw-frame initial-delay, burst-delay and system-lifetime
 * counters, and invokes module update vfuncs without a dt parameter. The
 * surrounding W3D/client renderer continues at 60 Hz. */
static void THISCALL update_particles_at_retail_rate(void *manager) {
    if (!manager || !g_original_particle_update) return;
    if (RA3_TARGET_FPS <= RA3_RETAIL_VISUAL_FPS) {
        g_original_particle_update(manager);
        return;
    }
    g_particle_update_accumulator += RA3_RETAIL_VISUAL_FPS;
    if (g_particle_update_accumulator >= RA3_TARGET_FPS) {
        g_particle_update_accumulator -= RA3_TARGET_FPS;
        g_original_particle_update(manager);
    }
}
#endif

/* Fixed-point W3D clock. The current accumulated value may reset between
 * sessions; a backwards jump resets only the fractional remainder. */
static uint32_t WINAPI advance_w3d_time_v12(uint32_t client_frame_delta) {
    volatile uint32_t *accumulated=(volatile uint32_t *)(g_ra3_game_module+RVA_W3D_ACCUMULATED_TIME_MS);
    volatile uint32_t *live_step=(volatile uint32_t *)(g_ra3_game_module+RVA_W3D_MILLISECONDS_FRAME);
    uint32_t current=*accumulated;
    uint32_t scaled,elapsed;
    if(current<g_w3d_last_accumulated) g_w3d_time_remainder=0;
    scaled=g_w3d_time_remainder + client_frame_delta*RA3_W3D_RETAIL_MS_PER_SECOND;
    elapsed=scaled/RA3_TARGET_FPS;
    g_w3d_time_remainder=scaled%RA3_TARGET_FPS;
    current+=elapsed;
    *accumulated=current;
    *live_step=(g_w3d_time_remainder+RA3_W3D_RETAIL_MS_PER_SECOND)/RA3_TARGET_FPS;
    g_w3d_last_accumulated=current;
    return current;
}

typedef uint32_t (THISCALL *GameClientGetFrameNumberFn)(void *game_client);
static uint32_t THISCALL get_retail_visual_frame_v12(void *game_client) {
    void **vtable;
    GameClientGetFrameNumberFn get_frame;
    uint32_t actual,whole,rem;
    if(!game_client) return 0;
    vtable=*(void ***)game_client;
    get_frame=(GameClientGetFrameNumberFn)vtable[0x74UL/sizeof(void*)];
    actual=get_frame(game_client);
    if(RA3_TARGET_FPS<=RA3_RETAIL_VISUAL_FPS) return actual;
    whole=(actual/RA3_TARGET_FPS)*RA3_RETAIL_VISUAL_FPS;
    rem=actual%RA3_TARGET_FPS;
    return whole + (rem*RA3_RETAIL_VISUAL_FPS + RA3_TARGET_FPS - 1UL)/RA3_TARGET_FPS;
}

static BOOL validate_systemic_v12_sites(void) {
    unsigned char *special=g_ra3_game_module+RVA_W3D_SPECIAL_ADVANCE;
    unsigned char *normal=g_ra3_game_module+RVA_W3D_NORMAL_ADVANCE;
    unsigned char *anim_set=g_ra3_game_module+RVA_ANIM2D_TIMESTAMP_CALL;
    unsigned char *anim_update=g_ra3_game_module+RVA_ANIM2D_UPDATE_CALL;
    unsigned char *tracer_reset=g_ra3_game_module+RVA_TRACER_RESET_CALL;
    unsigned char *tracer_update=g_ra3_game_module+RVA_TRACER_UPDATE_CALL;
    unsigned char *cloud=g_ra3_game_module+RVA_CLOUD_FRAME_CALL;
    uint32_t accum=(uint32_t)(uintptr_t)(g_ra3_game_module+RVA_W3D_ACCUMULATED_TIME_MS);
    uint32_t step=(uint32_t)(uintptr_t)(g_ra3_game_module+RVA_W3D_MILLISECONDS_FRAME);
    if(!(special[0]==0xA1 && special[5]==0x03 && special[6]==0x05 && special[11]==0x50 && special[12]==0xA3)) return FALSE;
    if(read_u32(special+1)!=accum || read_u32(special+7)!=step || read_u32(special+13)!=accum) return FALSE;
    if(!(normal[0]==0x8B && normal[1]==0x0D && normal[6]==0xA1 && normal[11]==0x0F && normal[12]==0xAF && normal[13]==0xCE && normal[14]==0x03 && normal[15]==0xC1 && normal[16]==0x50 && normal[17]==0xA3)) return FALSE;
    if(read_u32(normal+2)!=step || read_u32(normal+7)!=accum || read_u32(normal+18)!=accum) return FALSE;
    return equal_bytes(anim_set,g_anim2d_timestamp_expected,sizeof(g_anim2d_timestamp_expected)) &&
           equal_bytes(anim_update,g_frame_call_expected,sizeof(g_frame_call_expected)) &&
           equal_bytes(tracer_reset,g_tracer_reset_expected,sizeof(g_tracer_reset_expected)) &&
           equal_bytes(tracer_update,g_frame_call_expected,sizeof(g_frame_call_expected)) &&
           equal_bytes(cloud,g_frame_call_expected,sizeof(g_frame_call_expected));
}

static BOOL validate_interp_block(unsigned char *site) {
    SIZE_T i;
    uint32_t expected_abs=(uint32_t)(uintptr_t)(g_ra3_game_module+RVA_ONE_SIXTH_FLOAT);
    for(i=0;i<sizeof(g_interp_expected);++i) {
        if(i>=11 && i<15) continue;
        if(site[i]!=g_interp_expected[i]) return FALSE;
    }
    return read_u32(site+11)==expected_abs;
}
#if RA3_PARTICLE_GATE
static const unsigned char g_fx_initial_delay_expected[8] = {
    0x83,0xC0,0xFF,0x89,0x46,0x3C,0x75,0x13
};
static const unsigned char g_fx_emission_countdown_expected[16] = {
    0x8B,0x86,0x04,0x01,0x00,0x00,0x85,0xC0,
    0x75,0x5E,0x8D,0x8D,0xA8,0x00,0x00,0x00
};
static const unsigned char g_fx_system_lifetime_expected[15] = {
    0x83,0xC0,0xFF,0x89,0x86,0x0C,0x01,0x00,0x00,
    0x8B,0x8E,0x90,0x00,0x00,0x00
};
static BOOL validate_fx_authored_30_domain(void) {
    return equal_bytes(g_ra3_game_module+RVA_FX_INITIAL_DELAY_DEC,
                       g_fx_initial_delay_expected,sizeof(g_fx_initial_delay_expected)) &&
           equal_bytes(g_ra3_game_module+RVA_FX_EMISSION_COUNTDOWN,
                       g_fx_emission_countdown_expected,sizeof(g_fx_emission_countdown_expected)) &&
           equal_bytes(g_ra3_game_module+RVA_FX_SYSTEM_LIFETIME_DEC,
                       g_fx_system_lifetime_expected,sizeof(g_fx_system_lifetime_expected));
}
static BOOL validate_particle_call(unsigned char *site) {
    int32_t rel;
    unsigned char *target;
    if(site[0]!=0xE8) return FALSE;
    rel=(int32_t)read_u32(site+1);
    target=site+5+rel;
    return target==g_ra3_game_module+RVA_PARTICLE_SIM_TARGET;
}
#endif
static BOOL validate_particle_domain_init(unsigned char *mov_site, unsigned char *fild_site, uint32_t render_abs) {
    static const unsigned char mov_opcode = 0xA1;
    static const unsigned char fild_opcode[2] = {0xDB,0x05};
    if (mov_site[0] != mov_opcode || !equal_bytes(fild_site,fild_opcode,2)) return FALSE;
    return read_u32(mov_site+1)==render_abs && read_u32(fild_site+2)==render_abs;
}
static BOOL validate_gpu_particle_create(unsigned char *site, uint32_t live_frames_ms_abs) {
    static const unsigned char opcode[2] = {0xD8,0x0D};
    if(!equal_bytes(site,opcode,2)) return FALSE;
    return read_u32(site+2)==live_frames_ms_abs;
}
static BOOL validate_gpu_particle_fps(unsigned char *site, uint32_t render_abs) {
    static const unsigned char opcode[3] = {0x0F,0xAF,0x05};
    if(!equal_bytes(site,opcode,3)) return FALSE;
    return read_u32(site+3)==render_abs;
}
static BOOL validate_model_step(unsigned char *site) {
    static const unsigned char opcode[4]={0xF3,0x0F,0x58,0x05};
    if(!equal_bytes(site,opcode,4)) return FALSE;
    return read_u32(site+4)==(uint32_t)(uintptr_t)(g_ra3_game_module+RVA_RETAIL_VISUAL_STEP);
}
static BOOL validate_camera_step(unsigned char *site) {
    /* fld dword ptr [0x00BF1070] -- the same retail 1/30 constant used by
     * upstream's continuous camera-step patch. Only the absolute operand moves. */
    static const unsigned char opcode[2]={0xD9,0x05};
    if(!equal_bytes(site,opcode,2)) return FALSE;
    return read_u32(site+2)==(uint32_t)(uintptr_t)(g_ra3_game_module+RVA_RETAIL_VISUAL_STEP);
}

#if RA3_CLIENT_SLICE_FLUSH
static BOOL validate_client_slice_flush(unsigned char *site) {
    static const unsigned char skip_expected[7]={0x83,0x7C,0x24,0x40,0x05,0x75,0x5B};
    if(!equal_bytes(site,g_flush_expected,sizeof(g_flush_expected))) return FALSE;
    if(RVA_CLIENT_SLICE_FLUSH_CONT!=RVA_CLIENT_SLICE_FLUSH_GATE+6UL) return FALSE;
    return equal_bytes(g_ra3_game_module+RVA_CLIENT_SLICE_FLUSH_SKIP,skip_expected,sizeof(skip_expected));
}
#endif
#if RA3_BOUNCE_TIMESTEP_FIX
static BOOL validate_bounce_timestep_sites(void) {
    unsigned char *kick=g_ra3_game_module+RVA_BOUNCEKICK_LOAD;
    unsigned char *pk=g_ra3_game_module+RVA_BOUNCE_PITCH_K_MUL;
    unsigned char *pd=g_ra3_game_module+RVA_BOUNCE_PITCH_D_MUL;
    unsigned char *rk=g_ra3_game_module+RVA_BOUNCE_ROLL_K_MUL;
    unsigned char *rd=g_ra3_game_module+RVA_BOUNCE_ROLL_D_MUL;
    unsigned char *pi=g_ra3_game_module+RVA_BOUNCE_PITCH_INTEGRATE;
    unsigned char *ri=g_ra3_game_module+RVA_BOUNCE_ROLL_INTEGRATE;
    return equal_bytes(kick,g_bouncekick_load_expected,12) &&
           equal_bytes(pk,g_bounce_pitch_k_expected,sizeof(g_bounce_pitch_k_expected)) &&
           equal_bytes(pd,g_bounce_pitch_d_expected,sizeof(g_bounce_pitch_d_expected)) &&
           equal_bytes(rk,g_bounce_roll_k_expected,sizeof(g_bounce_roll_k_expected)) &&
           equal_bytes(rd,g_bounce_roll_d_expected,sizeof(g_bounce_roll_d_expected)) &&
           equal_bytes(pi,g_bounce_pitch_integrate_expected,sizeof(g_bounce_pitch_integrate_expected)) &&
           equal_bytes(ri,g_bounce_roll_integrate_expected,sizeof(g_bounce_roll_integrate_expected)) &&
           equal_bytes(g_ra3_game_module+RVA_ATTACH_SPRING_PITCH_K_MUL,g_attach_pitch_k_expected,sizeof(g_attach_pitch_k_expected)) &&
           equal_bytes(g_ra3_game_module+RVA_ATTACH_SPRING_EXTERNAL_FORCE,g_attach_external_expected,sizeof(g_attach_external_expected)) &&
           equal_bytes(g_ra3_game_module+RVA_ATTACH_SPRING_PITCH_D_MUL,g_attach_pitch_d_expected,sizeof(g_attach_pitch_d_expected)) &&
           equal_bytes(g_ra3_game_module+RVA_ATTACH_SPRING_PITCH_INTEGRATE,g_attach_pitch_integrate_expected,sizeof(g_attach_pitch_integrate_expected)) &&
           equal_bytes(g_ra3_game_module+RVA_ATTACH_SPRING_ROLL_K_MUL,g_attach_roll_k_expected,sizeof(g_attach_roll_k_expected)) &&
           equal_bytes(g_ra3_game_module+RVA_ATTACH_SPRING_ROLL_D_MUL,g_attach_roll_d_expected,sizeof(g_attach_roll_d_expected)) &&
           equal_bytes(g_ra3_game_module+RVA_ATTACH_SPRING_ROLL_INTEGRATE,g_attach_roll_integrate_expected,sizeof(g_attach_roll_integrate_expected));
}
#endif
static BOOL validate_loco_correction_sites(void) {
    return equal_bytes(g_ra3_game_module+RVA_LOCO_CORRECTION_HELPER,
                       g_loco_correction_helper_expected,sizeof(g_loco_correction_helper_expected)) &&
           equal_bytes(g_ra3_game_module+RVA_AELERON_PHASE_LOAD,
                       g_aeleron_phase_load_expected,sizeof(g_aeleron_phase_load_expected)) &&
           equal_bytes(g_ra3_game_module+RVA_ELEVATOR_PHASE_ADD,
                       g_elevator_phase_add_expected,sizeof(g_elevator_phase_add_expected));
}
/* Resolve every patch site from code signatures instead of from one EXE hash.
 * This supports stock 1.1..1.12 and modified 1.12 builds as long as the
 * relevant RA3 routines preserve the validated machine-code contracts. */
static BOOL resolve_adaptive_sites(unsigned char *module,const Ra3PeInfo *pe,uint32_t render_abs) {
    unsigned char *p=NULL,*q=NULL; uint32_t abs=0,rva=0; SIZE_T i; unsigned matches;
    static const unsigned char interp_mask[50]={
        1,1,1,1,1,1,1,1,1,1,1, 0,0,0,0,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1
    };
#if RA3_BOUNCE_TIMESTEP_FIX
    static const unsigned char kick_mask[16]={1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0};
#endif
    static const unsigned char w3ds_pat[17]={0xA1,0,0,0,0,0x03,0x05,0,0,0,0,0x50,0xA3,0,0,0,0};
    static const unsigned char w3ds_mask[17]={1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0};
    static const unsigned char w3dn_pat[22]={0x8B,0x0D,0,0,0,0,0xA1,0,0,0,0,0x0F,0xAF,0xCE,0x03,0xC1,0x50,0xA3,0,0,0,0};
    static const unsigned char w3dn_mask[22]={1,1,0,0,0,0,1,0,0,0,0,1,1,1,1,1,1,1,0,0,0,0};
    static const unsigned char model_pat[33]={0xF3,0x0F,0x10,0x87,0x48,0x02,0x00,0x00,0xF3,0x0F,0x58,0x05,0,0,0,0,0xF3,0x0F,0x10,0x0D,0,0,0,0,0x0F,0x2F,0xC1,0x89,0x87,0x4C,0x02,0x00,0x00};
    static const unsigned char model_mask[33]={1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,1,1};
    static const unsigned char client_pat[35]={0xA1,0,0,0,0,0xDB,0x05,0,0,0,0,0x85,0xC0,0x7D,0x06,0xD8,0x05,0,0,0,0,0xD8,0x0D,0,0,0,0,0xD9,0x1D,0,0,0,0,0x59,0xC3};
    static const unsigned char client_mask[35]={1,0,0,0,0,1,1,0,0,0,0,1,1,1,1,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1};
    static const unsigned char gpu_create_pat[19]={0xD8,0x0D,0,0,0,0,0x85,0xC0,0xDB,0x46,0x28,0x7D,0x06,0xD8,0x05,0,0,0,0};
    static const unsigned char gpu_create_mask[19]={1,1,0,0,0,0,1,1,1,1,1,1,1,1,1,0,0,0,0};
    static const unsigned char gpu_fps_pat[25]={0x0F,0xAF,0x05,0,0,0,0,0x85,0xC0,0x89,0x44,0x24,0x04,0xDB,0x44,0x24,0x04,0x7D,0x06,0xD8,0x05,0,0,0,0};
    static const unsigned char gpu_fps_mask[25]={1,1,1,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0};
    static const unsigned char anim_pat[19]={0x56,0x8B,0xF1,0x8B,0x0D,0,0,0,0,0x8B,0x01,0x8B,0x50,0x74,0xFF,0xD2,0x2B,0x46,0x08};
    static const unsigned char anim_mask[19]={1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,1,1,1};
    static const unsigned char tracer_pat[25]={0x56,0x8B,0xF1,0x0F,0x84,0,0,0,0,0x8B,0x0D,0,0,0,0,0x8B,0x01,0x8B,0x50,0x74,0xFF,0xD2,0x3B,0x46,0x20};
    static const unsigned char tracer_mask[25]={1,1,1,1,1,0,0,0,0,1,1,0,0,0,0,1,1,1,1,1,1,1,1,1,1};
    static const unsigned char cloud_pat[24]={0x83,0xEC,0x0C,0x56,0x8B,0xF1,0x8B,0x0D,0,0,0,0,0x8B,0x01,0x8B,0x50,0x74,0xFF,0xD2,0x32,0xC9,0x39,0x46,0x7C};
    static const unsigned char cloud_mask[24]={1,1,1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1};
#if RA3_PARTICLE_GATE
    static const unsigned char particle_pat[34]={0x51,0xA1,0,0,0,0,0x80,0xB8,0xC4,0x00,0x00,0x00,0x00,0x53,0x55,0x56,0x57,0x8B,0xD9,0x74,0x14,0x8B,0x0D,0,0,0,0,0x80,0xB9,0x70,0x01,0x00,0x00,0x00};
    static const unsigned char particle_mask[34]={1,1,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1};
#endif

    if(!find_unique_exec_exact(module,pe,g_batch_expected,sizeof(g_batch_expected),&p)) return FALSE;
    RVA_PHASE_BATCH_BLOCK=(uint32_t)(p-module);
    if(!find_unique_exec_masked(module,pe,g_interp_expected,interp_mask,sizeof(g_interp_expected),&p)) return FALSE;
    RVA_PHASE_INTERP_BLOCK=(uint32_t)(p-module); RVA_PHASE_INTERP_REJOIN=RVA_PHASE_INTERP_BLOCK+50UL;
    abs=read_u32(p+11); if(!absolute_to_rva(module,pe->size_of_image,abs,&rva)) return FALSE; RVA_ONE_SIXTH_FLOAT=rva;

#if RA3_CLIENT_SLICE_FLUSH
    if(!find_unique_exec_exact(module,pe,g_flush_expected,sizeof(g_flush_expected),&p)) return FALSE;
    RVA_CLIENT_SLICE_FLUSH_GATE=(uint32_t)(p-module); RVA_CLIENT_SLICE_FLUSH_CONT=RVA_CLIENT_SLICE_FLUSH_GATE+6UL;
    { static const unsigned char skip_pat[7]={0x83,0x7C,0x24,0x40,0x05,0x75,0x5B};
      matches=0; q=NULL;
      for(i=0x35;i<=0x70;++i) if(ptr_inside_image(module,pe->size_of_image,p+i,sizeof(skip_pat)) && equal_bytes(p+i,skip_pat,sizeof(skip_pat))) { q=p+i; ++matches; }
      if(matches!=1) return FALSE; RVA_CLIENT_SLICE_FLUSH_SKIP=(uint32_t)(q-module); }
#endif

#if RA3_PARTICLE_GATE
    if(!find_unique_exec_exact(module,pe,g_fx_initial_delay_expected,sizeof(g_fx_initial_delay_expected),&p)) return FALSE; RVA_FX_INITIAL_DELAY_DEC=(uint32_t)(p-module);
    if(!find_unique_exec_exact(module,pe,g_fx_emission_countdown_expected,sizeof(g_fx_emission_countdown_expected),&p)) return FALSE; RVA_FX_EMISSION_COUNTDOWN=(uint32_t)(p-module);
    if(!find_unique_exec_exact(module,pe,g_fx_system_lifetime_expected,sizeof(g_fx_system_lifetime_expected),&p)) return FALSE; RVA_FX_SYSTEM_LIFETIME_DEC=(uint32_t)(p-module);
    if(!find_unique_exec_masked(module,pe,particle_pat,particle_mask,sizeof(particle_pat),&p)) return FALSE;
    RVA_PARTICLE_SIM_TARGET=(uint32_t)(p-module);
    if(!find_unique_call_to(module,pe,p,&q)) return FALSE; RVA_PARTICLE_SIM_CALL=(uint32_t)(q-module);
#endif

    /* Client frames/ms initializer: two similar functions exist; render_abs selects the render one. */
    matches=0; q=NULL;
    { WORD si; for(si=0;si<pe->section_count;++si) {
        const unsigned char *sec=pe->section_table+(DWORD)si*40UL; DWORD j,size=read_u32(sec+8),va=read_u32(sec+12),ch=read_u32(sec+36); unsigned char *st;
        if((ch&0x20000000UL)==0 || size<sizeof(client_pat) || va>=pe->size_of_image || size>pe->size_of_image-va) continue; st=module+va;
        for(j=0;j<=size-sizeof(client_pat);++j) if(masked_bytes_match(st+j,client_pat,client_mask,sizeof(client_pat)) && read_u32(st+j+1)==render_abs) {q=st+j; ++matches;}
      }}
    if(matches!=1) return FALSE;
    RVA_CLIENT_FRAMES_MS_INIT_MOV=(uint32_t)(q-module); RVA_CLIENT_FRAMES_MS_INIT_FILD=RVA_CLIENT_FRAMES_MS_INIT_MOV+5UL;
    abs=read_u32(q+29); if(!absolute_to_rva(module,pe->size_of_image,abs,&rva)) return FALSE; RVA_CLIENT_FRAMES_MS_VALUE=rva;

    if(!find_unique_exec_masked(module,pe,gpu_create_pat,gpu_create_mask,sizeof(gpu_create_pat),&p)) return FALSE; RVA_GPU_PARTICLE_CREATE_FMUL=(uint32_t)(p-module);
    if(!find_unique_exec_masked(module,pe,gpu_fps_pat,gpu_fps_mask,sizeof(gpu_fps_pat),&p)) return FALSE; RVA_GPU_PARTICLE_FPS_INSN=(uint32_t)(p-module);

    if(!find_unique_exec_masked(module,pe,model_pat,model_mask,sizeof(model_pat),&p)) return FALSE;
    RVA_MODEL_STEP_INSTRUCTION=(uint32_t)(p-module)+8UL;
    abs=read_u32(module+RVA_MODEL_STEP_INSTRUCTION+4UL); if(!absolute_to_rva(module,pe->size_of_image,abs,&rva)) return FALSE; RVA_RETAIL_VISUAL_STEP=rva;
    { unsigned char cam_pat[6]={0xD9,0x05,0,0,0,0}; encode_u32(cam_pat+2,abs);
      if(!find_unique_exec_bytes(module,pe,cam_pat,sizeof(cam_pat),&q)) return FALSE; RVA_CAMERA_STEP_INSTRUCTION=(uint32_t)(q-module); }

    if(!find_unique_exec_masked(module,pe,w3ds_pat,w3ds_mask,sizeof(w3ds_pat),&p)) return FALSE; RVA_W3D_SPECIAL_ADVANCE=(uint32_t)(p-module);
    { uint32_t a1=read_u32(p+1), stp=read_u32(p+7), a2=read_u32(p+13); if(a1!=a2) return FALSE;
      if(!absolute_to_rva(module,pe->size_of_image,a1,&rva)) return FALSE; RVA_W3D_ACCUMULATED_TIME_MS=rva;
      if(!absolute_to_rva(module,pe->size_of_image,stp,&rva)) return FALSE; RVA_W3D_MILLISECONDS_FRAME=rva; }
    if(!find_unique_exec_masked(module,pe,w3dn_pat,w3dn_mask,sizeof(w3dn_pat),&p)) return FALSE; RVA_W3D_NORMAL_ADVANCE=(uint32_t)(p-module);
    if(read_u32(p+2)!=(uint32_t)(uintptr_t)(module+RVA_W3D_MILLISECONDS_FRAME) || read_u32(p+7)!=(uint32_t)(uintptr_t)(module+RVA_W3D_ACCUMULATED_TIME_MS) || read_u32(p+18)!=(uint32_t)(uintptr_t)(module+RVA_W3D_ACCUMULATED_TIME_MS)) return FALSE;

    if(!find_unique_exec_masked(module,pe,anim_pat,anim_mask,sizeof(anim_pat),&p)) return FALSE;
    RVA_ANIM2D_UPDATE_CALL=(uint32_t)(p-module)+9UL; if(RVA_ANIM2D_UPDATE_CALL<0xC4UL) return FALSE; RVA_ANIM2D_TIMESTAMP_CALL=RVA_ANIM2D_UPDATE_CALL-0xC4UL;
    if(!find_unique_exec_masked(module,pe,tracer_pat,tracer_mask,sizeof(tracer_pat),&p)) return FALSE;
    RVA_TRACER_UPDATE_CALL=(uint32_t)(p-module)+15UL; if(RVA_TRACER_UPDATE_CALL<0xDCUL) return FALSE; RVA_TRACER_RESET_CALL=RVA_TRACER_UPDATE_CALL-0xDCUL;
    if(!find_unique_exec_masked(module,pe,cloud_pat,cloud_mask,sizeof(cloud_pat),&p)) return FALSE; RVA_CLOUD_FRAME_CALL=(uint32_t)(p-module)+12UL;

    if(!find_unique_exec_exact(module,pe,g_loco_correction_helper_expected,sizeof(g_loco_correction_helper_expected),&p)) return FALSE;
    RVA_LOCO_CORRECTION_HELPER=(uint32_t)(p-module); RVA_AELERON_PHASE_LOAD=RVA_LOCO_CORRECTION_HELPER+0x55UL; RVA_ELEVATOR_PHASE_ADD=RVA_LOCO_CORRECTION_HELPER+0x90UL;

#if RA3_BOUNCE_TIMESTEP_FIX
    if(!find_unique_exec_masked(module,pe,g_bouncekick_load_expected,kick_mask,sizeof(g_bouncekick_load_expected),&p)) return FALSE; RVA_BOUNCEKICK_LOAD=(uint32_t)(p-module);
    if(!find_unique_exec_exact(module,pe,g_bounce_pitch_integrate_expected,sizeof(g_bounce_pitch_integrate_expected),&p)) return FALSE;
    RVA_BOUNCE_PITCH_INTEGRATE=(uint32_t)(p-module);
    if(RVA_BOUNCE_PITCH_INTEGRATE<0x7BUL) return FALSE;
    RVA_BOUNCE_PITCH_K_MUL=RVA_BOUNCE_PITCH_INTEGRATE-0x7BUL;
    RVA_BOUNCE_PITCH_D_MUL=RVA_BOUNCE_PITCH_INTEGRATE-0x63UL;
    RVA_BOUNCE_ROLL_K_MUL=RVA_BOUNCE_PITCH_INTEGRATE-0x33UL;
    RVA_BOUNCE_ROLL_D_MUL=RVA_BOUNCE_PITCH_INTEGRATE-0x23UL;
    RVA_BOUNCE_ROLL_INTEGRATE=RVA_BOUNCE_PITCH_INTEGRATE+0x1CUL;
    RVA_ATTACH_SPRING_PITCH_K_MUL=RVA_BOUNCE_PITCH_INTEGRATE+0x27EUL;
    RVA_ATTACH_SPRING_EXTERNAL_FORCE=RVA_ATTACH_SPRING_PITCH_K_MUL+0x06UL;
    RVA_ATTACH_SPRING_PITCH_D_MUL=RVA_ATTACH_SPRING_PITCH_K_MUL+0x16UL;
    RVA_ATTACH_SPRING_PITCH_INTEGRATE=RVA_ATTACH_SPRING_PITCH_K_MUL+0x3AUL;
    RVA_ATTACH_SPRING_ROLL_K_MUL=RVA_ATTACH_SPRING_PITCH_K_MUL+0x6DUL;
    RVA_ATTACH_SPRING_ROLL_D_MUL=RVA_ATTACH_SPRING_PITCH_K_MUL+0x7DUL;
    RVA_ATTACH_SPRING_ROLL_INTEGRATE=RVA_ATTACH_SPRING_PITCH_K_MUL+0x9DUL;
#endif
    return TRUE;
}

static BOOL install_targeted_hooks(uint32_t *render_ptr) {
    unsigned char *batch=g_ra3_game_module+RVA_PHASE_BATCH_BLOCK;
    unsigned char *interp=g_ra3_game_module+RVA_PHASE_INTERP_BLOCK;
#if RA3_PARTICLE_GATE
    unsigned char *particle=g_ra3_game_module+RVA_PARTICLE_SIM_CALL;
#endif
    unsigned char *client_init_mov=g_ra3_game_module+RVA_CLIENT_FRAMES_MS_INIT_MOV;
    unsigned char *client_init_fild=g_ra3_game_module+RVA_CLIENT_FRAMES_MS_INIT_FILD;
    unsigned char *gpu_particle_create=g_ra3_game_module+RVA_GPU_PARTICLE_CREATE_FMUL;
    unsigned char *gpu_particle=g_ra3_game_module+RVA_GPU_PARTICLE_FPS_INSN;
    unsigned char *model=g_ra3_game_module+RVA_MODEL_STEP_INSTRUCTION;
    unsigned char *camera=g_ra3_game_module+RVA_CAMERA_STEP_INSTRUCTION;
    unsigned char *w3d_special=g_ra3_game_module+RVA_W3D_SPECIAL_ADVANCE;
    unsigned char *w3d_normal=g_ra3_game_module+RVA_W3D_NORMAL_ADVANCE;
    unsigned char *anim2d_set=g_ra3_game_module+RVA_ANIM2D_TIMESTAMP_CALL;
    unsigned char *anim2d_update=g_ra3_game_module+RVA_ANIM2D_UPDATE_CALL;
    unsigned char *tracer_reset=g_ra3_game_module+RVA_TRACER_RESET_CALL;
    unsigned char *tracer_update=g_ra3_game_module+RVA_TRACER_UPDATE_CALL;
    unsigned char *cloud_frame=g_ra3_game_module+RVA_CLOUD_FRAME_CALL;
    unsigned char *aeleron_phase=g_ra3_game_module+RVA_AELERON_PHASE_LOAD;
    unsigned char *elevator_phase=g_ra3_game_module+RVA_ELEVATOR_PHASE_ADD;
#if RA3_CLIENT_SLICE_FLUSH
    unsigned char *flush=g_ra3_game_module+RVA_CLIENT_SLICE_FLUSH_GATE;
#endif
#if RA3_BOUNCE_TIMESTEP_FIX
    unsigned char *bounce_pk=g_ra3_game_module+RVA_BOUNCE_PITCH_K_MUL;
    unsigned char *bounce_pd=g_ra3_game_module+RVA_BOUNCE_PITCH_D_MUL;
    unsigned char *bounce_rk=g_ra3_game_module+RVA_BOUNCE_ROLL_K_MUL;
    unsigned char *bounce_rd=g_ra3_game_module+RVA_BOUNCE_ROLL_D_MUL;
    unsigned char *bounce_pi=g_ra3_game_module+RVA_BOUNCE_PITCH_INTEGRATE;
    unsigned char *bounce_ri=g_ra3_game_module+RVA_BOUNCE_ROLL_INTEGRATE;
    unsigned char *attach_pk=g_ra3_game_module+RVA_ATTACH_SPRING_PITCH_K_MUL;
    unsigned char *attach_ext=g_ra3_game_module+RVA_ATTACH_SPRING_EXTERNAL_FORCE;
    unsigned char *attach_pd=g_ra3_game_module+RVA_ATTACH_SPRING_PITCH_D_MUL;
    unsigned char *attach_pi=g_ra3_game_module+RVA_ATTACH_SPRING_PITCH_INTEGRATE;
    unsigned char *attach_rk=g_ra3_game_module+RVA_ATTACH_SPRING_ROLL_K_MUL;
    unsigned char *attach_rd=g_ra3_game_module+RVA_ATTACH_SPRING_ROLL_D_MUL;
    unsigned char *attach_ri=g_ra3_game_module+RVA_ATTACH_SPRING_ROLL_INTEGRATE;
#endif
    unsigned char batch_old[41],interp_old[50],model_old[4],camera_old[4];
    unsigned char w3d_special_old[17],w3d_normal_old[22],w3d_special_patch[17],w3d_normal_patch[22];
    unsigned char anim2d_set_old[10],anim2d_update_old[7],tracer_reset_old[7],tracer_update_old[7],cloud_old[7];
    unsigned char anim2d_set_patch[10],anim2d_update_patch[7],tracer_reset_patch[7],tracer_update_patch[7],cloud_patch[7];
    unsigned char aeleron_old[5],elevator_old[5],aeleron_patch[5],elevator_patch[5];
#if RA3_CLIENT_SLICE_FLUSH
    unsigned char flush_old[5],flush_patch[5];
#endif
#if RA3_BOUNCE_TIMESTEP_FIX
    unsigned char bounce_pk_old[6],bounce_pd_old[6],bounce_rk_old[6],bounce_rd_old[6];
    unsigned char bounce_pi_old[17],bounce_ri_old[14];
    unsigned char bounce_pk_patch[6],bounce_pd_patch[6],bounce_rk_patch[6],bounce_rd_patch[6];
    unsigned char bounce_pi_patch[17],bounce_ri_patch[14];
    unsigned char attach_pk_old[6],attach_ext_old[6],attach_pd_old[6],attach_rk_old[6],attach_rd_old[6],attach_pi_old[10],attach_ri_old[10];
    unsigned char attach_pk_patch[6],attach_ext_patch[6],attach_pd_patch[6],attach_rk_patch[6],attach_rd_patch[6],attach_pi_patch[10],attach_ri_patch[10];
#endif
    unsigned char gpu_create_old[4],gpu_fps_old[4];
    unsigned char batch_patch[41],interp_patch[50];
#if RA3_PARTICLE_GATE
    unsigned char particle_old[5],particle_patch[5];
#endif
    uint32_t model_replacement=(uint32_t)(uintptr_t)&g_visual_client_step;
    uint32_t camera_replacement=(uint32_t)(uintptr_t)&g_visual_client_step;
    uint32_t retail_fps_ptr=(uint32_t)(uintptr_t)&g_retail_visual_fps_storage;
    uint32_t retail_frames_ms_ptr=(uint32_t)(uintptr_t)&g_retail_frames_per_millisecond;
    uint32_t render_abs=(uint32_t)(uintptr_t)render_ptr;
    uint32_t live_frames_ms_abs=(uint32_t)(uintptr_t)(g_ra3_game_module+RVA_CLIENT_FRAMES_MS_VALUE);
    BOOL wrote_render=FALSE,wrote_batch=FALSE,wrote_interp=FALSE,wrote_particle=FALSE,wrote_model=FALSE,wrote_camera=FALSE;
    BOOL wrote_gpu_create=FALSE,wrote_gpu_fps=FALSE;
    BOOL wrote_w3d_special=FALSE,wrote_w3d_normal=FALSE,wrote_anim2d_set=FALSE,wrote_anim2d_update=FALSE;
    BOOL wrote_tracer_reset=FALSE,wrote_tracer_update=FALSE,wrote_cloud=FALSE;
    BOOL wrote_aeleron=FALSE,wrote_elevator=FALSE;
#if RA3_CLIENT_SLICE_FLUSH
    BOOL wrote_flush=FALSE;
#endif
#if RA3_BOUNCE_TIMESTEP_FIX
    BOOL wrote_bounce_pk=FALSE,wrote_bounce_pd=FALSE,wrote_bounce_rk=FALSE,wrote_bounce_rd=FALSE;
    BOOL wrote_bounce_pi=FALSE,wrote_bounce_ri=FALSE;
    BOOL wrote_attach_pk=FALSE,wrote_attach_ext=FALSE,wrote_attach_pd=FALSE,wrote_attach_pi=FALSE;
    BOOL wrote_attach_rk=FALSE,wrote_attach_rd=FALSE,wrote_attach_ri=FALSE;
#endif

    /* Validate every site that this build will touch before writing anything. */
    if(!equal_bytes(batch,g_batch_expected,sizeof(g_batch_expected)) ||
       !validate_interp_block(interp) || !validate_model_step(model) || !validate_camera_step(camera) ||
       !validate_particle_domain_init(client_init_mov,client_init_fild,render_abs) ||
       !validate_gpu_particle_create(gpu_particle_create,live_frames_ms_abs) ||
       !validate_gpu_particle_fps(gpu_particle,render_abs) || !validate_systemic_v12_sites()) return FALSE;
#if RA3_CLIENT_SLICE_FLUSH
    if(!validate_client_slice_flush(flush)) return FALSE;
#endif
#if RA3_BOUNCE_TIMESTEP_FIX
    if(!validate_bounce_timestep_sites()) return FALSE;
#endif
#if RA3_PARTICLE_GATE
    if(!validate_particle_call(particle) || !validate_fx_authored_30_domain()) return FALSE;
#endif
    if(!validate_loco_correction_sites()) return FALSE;

    copy_bytes(batch_old,batch,sizeof(batch_old));
    copy_bytes(interp_old,interp,sizeof(interp_old));
    copy_bytes(aeleron_old,aeleron_phase,sizeof(aeleron_old));
    copy_bytes(elevator_old,elevator_phase,sizeof(elevator_old));
#if RA3_CLIENT_SLICE_FLUSH
    copy_bytes(flush_old,flush,sizeof(flush_old));
#endif
#if RA3_BOUNCE_TIMESTEP_FIX
    copy_bytes(bounce_pk_old,bounce_pk,sizeof(bounce_pk_old));
    copy_bytes(bounce_pd_old,bounce_pd,sizeof(bounce_pd_old));
    copy_bytes(bounce_rk_old,bounce_rk,sizeof(bounce_rk_old));
    copy_bytes(bounce_rd_old,bounce_rd,sizeof(bounce_rd_old));
    copy_bytes(bounce_pi_old,bounce_pi,sizeof(bounce_pi_old));
    copy_bytes(bounce_ri_old,bounce_ri,sizeof(bounce_ri_old));
    copy_bytes(attach_pk_old,attach_pk,sizeof(attach_pk_old));
    copy_bytes(attach_ext_old,attach_ext,sizeof(attach_ext_old));
    copy_bytes(attach_pd_old,attach_pd,sizeof(attach_pd_old));
    copy_bytes(attach_pi_old,attach_pi,sizeof(attach_pi_old));
    copy_bytes(attach_rk_old,attach_rk,sizeof(attach_rk_old));
    copy_bytes(attach_rd_old,attach_rd,sizeof(attach_rd_old));
    copy_bytes(attach_ri_old,attach_ri,sizeof(attach_ri_old));
#endif
#if RA3_PARTICLE_GATE
    copy_bytes(particle_old,particle,sizeof(particle_old));
#endif
    copy_bytes(model_old,model+4,sizeof(model_old));
    copy_bytes(camera_old,camera+2,sizeof(camera_old));
    copy_bytes(gpu_create_old,gpu_particle_create+2,sizeof(gpu_create_old));
    copy_bytes(gpu_fps_old,gpu_particle+3,sizeof(gpu_fps_old));
    copy_bytes(w3d_special_old,w3d_special,sizeof(w3d_special_old));
    copy_bytes(w3d_normal_old,w3d_normal,sizeof(w3d_normal_old));
    copy_bytes(anim2d_set_old,anim2d_set,sizeof(anim2d_set_old));
    copy_bytes(anim2d_update_old,anim2d_update,sizeof(anim2d_update_old));
    copy_bytes(tracer_reset_old,tracer_reset,sizeof(tracer_reset_old));
    copy_bytes(tracer_update_old,tracer_update,sizeof(tracer_update_old));
    copy_bytes(cloud_old,cloud_frame,sizeof(cloud_old));

    fill_bytes(w3d_special_patch,0x90,sizeof(w3d_special_patch));
    w3d_special_patch[0]=0x6A; w3d_special_patch[1]=0x01;
    w3d_special_patch[2]=0xE8;
    encode_rel32(w3d_special_patch+3,w3d_special+7,(const void*)advance_w3d_time_v12);
    w3d_special_patch[7]=0x50;

    fill_bytes(w3d_normal_patch,0x90,sizeof(w3d_normal_patch));
    w3d_normal_patch[0]=0x56;
    w3d_normal_patch[1]=0xE8;
    encode_rel32(w3d_normal_patch+2,w3d_normal+6,(const void*)advance_w3d_time_v12);
    w3d_normal_patch[6]=0x50;

    fill_bytes(anim2d_set_patch,0x90,sizeof(anim2d_set_patch));
    anim2d_set_patch[0]=0x83; anim2d_set_patch[1]=0xC4; anim2d_set_patch[2]=0x10;
    anim2d_set_patch[3]=0xE8;
    encode_rel32(anim2d_set_patch+4,anim2d_set+8,(const void*)get_retail_visual_frame_v12);

    fill_bytes(anim2d_update_patch,0x90,sizeof(anim2d_update_patch));
    anim2d_update_patch[0]=0xE8;
    encode_rel32(anim2d_update_patch+1,anim2d_update+5,(const void*)get_retail_visual_frame_v12);
    fill_bytes(tracer_reset_patch,0x90,sizeof(tracer_reset_patch));
    tracer_reset_patch[0]=0xE8;
    encode_rel32(tracer_reset_patch+1,tracer_reset+5,(const void*)get_retail_visual_frame_v12);
    fill_bytes(tracer_update_patch,0x90,sizeof(tracer_update_patch));
    tracer_update_patch[0]=0xE8;
    encode_rel32(tracer_update_patch+1,tracer_update+5,(const void*)get_retail_visual_frame_v12);
    fill_bytes(cloud_patch,0x90,sizeof(cloud_patch));
    cloud_patch[0]=0xE8;
    encode_rel32(cloud_patch+1,cloud_frame+5,(const void*)get_retail_visual_frame_v12);

    aeleron_patch[0]=0xE8;
    encode_rel32(aeleron_patch+1,aeleron_phase+5,(const void*)aeleron_phase_rate_step);
    elevator_patch[0]=0xE8;
    encode_rel32(elevator_patch+1,elevator_phase+5,(const void*)elevator_phase_rate_step);

    fill_bytes(batch_patch,0x90,sizeof(batch_patch));
    /* ESI=current phase, EDI=render/logic ratio. Helper is __stdcall. */
    batch_patch[0]=0x57;                 /* push edi (ratio) */
    batch_patch[1]=0x56;                 /* push esi (phase) */
    batch_patch[2]=0xE8;                 /* call helper */
    encode_rel32(batch_patch+3,batch+7,(const void*)get_phase_batch_limit);
    batch_patch[7]=0x8B; batch_patch[8]=0xF8; /* mov edi,eax */
    batch_patch[9]=0xBB; encode_u32(batch_patch+10,1UL); /* mov ebx,1 */
    batch_patch[14]=0x03; batch_patch[15]=0xF3; /* add esi,ebx */
    /* Rejoin at original 0x6551A7: cmp esi,edi. */

    fill_bytes(interp_patch,0x90,sizeof(interp_patch));
    interp_patch[0]=0x51;                /* push ecx: old/current phase */
    interp_patch[1]=0x56;                /* push esi: GameEngine* */
    interp_patch[2]=0xE8;
    encode_rel32(interp_patch+3,interp+7,(const void*)update_phase_interpolation_v4);
    interp_patch[7]=0x83; interp_patch[8]=0xF8; interp_patch[9]=0x06; /* cmp eax,6 */
    interp_patch[10]=0x57;               /* preserve original push edi without changing flags */
    interp_patch[11]=0xE9;               /* jump over replaced tail; JLE at rejoin uses CMP flags */
    encode_rel32(interp_patch+12,interp+16,g_ra3_game_module+RVA_PHASE_INTERP_REJOIN);

#if RA3_CLIENT_SLICE_FLUSH
    g_flush_continue_addr=(uintptr_t)(g_ra3_game_module+RVA_CLIENT_SLICE_FLUSH_CONT);
    g_flush_skip_addr=(uintptr_t)(g_ra3_game_module+RVA_CLIENT_SLICE_FLUSH_SKIP);
    flush_patch[0]=0xE9;
    encode_rel32(flush_patch+1,flush+5,(const void*)client_slice_flush_gate_trampoline);
#endif

#if RA3_BOUNCE_TIMESTEP_FIX
    fill_bytes(bounce_pk_patch,0x90,sizeof(bounce_pk_patch));
    bounce_pk_patch[0]=0xE8;
    encode_rel32(bounce_pk_patch+1,bounce_pk+5,(const void*)bounce_pitch_k_step);
    fill_bytes(bounce_pd_patch,0x90,sizeof(bounce_pd_patch));
    bounce_pd_patch[0]=0xE8;
    encode_rel32(bounce_pd_patch+1,bounce_pd+5,(const void*)bounce_pitch_d_step);
    fill_bytes(bounce_rk_patch,0x90,sizeof(bounce_rk_patch));
    bounce_rk_patch[0]=0xE8;
    encode_rel32(bounce_rk_patch+1,bounce_rk+5,(const void*)bounce_roll_k_step);
    fill_bytes(bounce_rd_patch,0x90,sizeof(bounce_rd_patch));
    bounce_rd_patch[0]=0xE8;
    encode_rel32(bounce_rd_patch+1,bounce_rd+5,(const void*)bounce_roll_d_step);
    fill_bytes(bounce_pi_patch,0x90,sizeof(bounce_pi_patch));
    bounce_pi_patch[0]=0xE8;
    encode_rel32(bounce_pi_patch+1,bounce_pi+5,(const void*)bounce_pitch_integrate_step);
    fill_bytes(bounce_ri_patch,0x90,sizeof(bounce_ri_patch));
    bounce_ri_patch[0]=0xE8;
    encode_rel32(bounce_ri_patch+1,bounce_ri+5,(const void*)bounce_roll_integrate_step);
#define MAKE_CALL_PATCH(buf,site,fn) do { fill_bytes((buf),0x90,sizeof(buf)); (buf)[0]=0xE8; encode_rel32((buf)+1,(site)+5,(const void*)(fn)); } while(0)
    MAKE_CALL_PATCH(attach_pk_patch,attach_pk,attach_pitch_k_step);
    MAKE_CALL_PATCH(attach_ext_patch,attach_ext,attach_external_step);
    MAKE_CALL_PATCH(attach_pd_patch,attach_pd,attach_pitch_d_step);
    MAKE_CALL_PATCH(attach_pi_patch,attach_pi,attach_pitch_integrate_step);
    MAKE_CALL_PATCH(attach_rk_patch,attach_rk,attach_roll_k_step);
    MAKE_CALL_PATCH(attach_rd_patch,attach_rd,attach_roll_d_step);
    MAKE_CALL_PATCH(attach_ri_patch,attach_ri,attach_roll_integrate_step);
#undef MAKE_CALL_PATCH
#endif

#if RA3_PARTICLE_GATE
    particle_patch[0]=0xE8;
    encode_rel32(particle_patch+1,particle+5,(const void*)update_particles_at_retail_rate);
    g_original_particle_update=(SubsystemUpdateFn)(g_ra3_game_module+RVA_PARTICLE_SIM_TARGET);
#endif

    /* Keep CE0DFC as RA3's live client frames/ms cache. With render_fps=60
     * its startup initializer must produce ~0.06 because StructureUnpackUpdate,
     * StructureSellUpdate and other continuous visual/gameplay consumers use it.
     * Only FxpsGPUStorageModule's timestamp creation and GPU expiry are pinned
     * to the synthetic retail-30 particle domain. */
    if(!write_u32(gpu_particle_create+2,retail_frames_ms_ptr,TRUE)) goto rollback;
    wrote_gpu_create=TRUE;
    if(!write_u32(gpu_particle+3,retail_fps_ptr,TRUE)) goto rollback;
    wrote_gpu_fps=TRUE;
    if(!write_u32(render_ptr,RA3_TARGET_FPS,FALSE)) goto rollback;
    wrote_render=TRUE;
    if(!write_memory(w3d_special,w3d_special_patch,sizeof(w3d_special_patch),TRUE)) goto rollback;
    wrote_w3d_special=TRUE;
    if(!write_memory(w3d_normal,w3d_normal_patch,sizeof(w3d_normal_patch),TRUE)) goto rollback;
    wrote_w3d_normal=TRUE;
    if(!write_memory(anim2d_set,anim2d_set_patch,sizeof(anim2d_set_patch),TRUE)) goto rollback;
    wrote_anim2d_set=TRUE;
    if(!write_memory(anim2d_update,anim2d_update_patch,sizeof(anim2d_update_patch),TRUE)) goto rollback;
    wrote_anim2d_update=TRUE;
    if(!write_memory(tracer_reset,tracer_reset_patch,sizeof(tracer_reset_patch),TRUE)) goto rollback;
    wrote_tracer_reset=TRUE;
    if(!write_memory(tracer_update,tracer_update_patch,sizeof(tracer_update_patch),TRUE)) goto rollback;
    wrote_tracer_update=TRUE;
    if(!write_memory(cloud_frame,cloud_patch,sizeof(cloud_patch),TRUE)) goto rollback;
    wrote_cloud=TRUE;
    if(!write_memory(aeleron_phase,aeleron_patch,sizeof(aeleron_patch),TRUE)) goto rollback;
    wrote_aeleron=TRUE;
    if(!write_memory(elevator_phase,elevator_patch,sizeof(elevator_patch),TRUE)) goto rollback;
    wrote_elevator=TRUE;
    if(!write_memory(batch,batch_patch,sizeof(batch_patch),TRUE)) goto rollback;
    wrote_batch=TRUE;
    if(!write_memory(interp,interp_patch,sizeof(interp_patch),TRUE)) goto rollback;
    wrote_interp=TRUE;
#if RA3_CLIENT_SLICE_FLUSH
    if(!write_memory(flush,flush_patch,sizeof(flush_patch),TRUE)) goto rollback;
    wrote_flush=TRUE;
#endif
#if RA3_BOUNCE_TIMESTEP_FIX
    if(!write_memory(bounce_pk,bounce_pk_patch,sizeof(bounce_pk_patch),TRUE)) goto rollback;
    wrote_bounce_pk=TRUE;
    if(!write_memory(bounce_pd,bounce_pd_patch,sizeof(bounce_pd_patch),TRUE)) goto rollback;
    wrote_bounce_pd=TRUE;
    if(!write_memory(bounce_rk,bounce_rk_patch,sizeof(bounce_rk_patch),TRUE)) goto rollback;
    wrote_bounce_rk=TRUE;
    if(!write_memory(bounce_rd,bounce_rd_patch,sizeof(bounce_rd_patch),TRUE)) goto rollback;
    wrote_bounce_rd=TRUE;
    if(!write_memory(bounce_pi,bounce_pi_patch,sizeof(bounce_pi_patch),TRUE)) goto rollback;
    wrote_bounce_pi=TRUE;
    if(!write_memory(bounce_ri,bounce_ri_patch,sizeof(bounce_ri_patch),TRUE)) goto rollback;
    wrote_bounce_ri=TRUE;
    if(!write_memory(attach_pk,attach_pk_patch,sizeof(attach_pk_patch),TRUE)) goto rollback;
    wrote_attach_pk=TRUE;
    if(!write_memory(attach_ext,attach_ext_patch,sizeof(attach_ext_patch),TRUE)) goto rollback;
    wrote_attach_ext=TRUE;
    if(!write_memory(attach_pd,attach_pd_patch,sizeof(attach_pd_patch),TRUE)) goto rollback;
    wrote_attach_pd=TRUE;
    if(!write_memory(attach_pi,attach_pi_patch,sizeof(attach_pi_patch),TRUE)) goto rollback;
    wrote_attach_pi=TRUE;
    if(!write_memory(attach_rk,attach_rk_patch,sizeof(attach_rk_patch),TRUE)) goto rollback;
    wrote_attach_rk=TRUE;
    if(!write_memory(attach_rd,attach_rd_patch,sizeof(attach_rd_patch),TRUE)) goto rollback;
    wrote_attach_rd=TRUE;
    if(!write_memory(attach_ri,attach_ri_patch,sizeof(attach_ri_patch),TRUE)) goto rollback;
    wrote_attach_ri=TRUE;
#endif
#if RA3_PARTICLE_GATE
    if(!write_memory(particle,particle_patch,sizeof(particle_patch),TRUE)) goto rollback;
    wrote_particle=TRUE;
#endif
    if(!write_u32(model+4,model_replacement,TRUE)) goto rollback;
    wrote_model=TRUE;
    if(!write_u32(camera+2,camera_replacement,TRUE)) goto rollback;
    wrote_camera=TRUE;
    g_scheduler_batch_installed=1;
    g_scheduler_interp_installed=1;
#if RA3_CLIENT_SLICE_FLUSH
    g_client_slice_flush_installed=1;
#else
    g_client_slice_flush_installed=0;
#endif
#if RA3_PARTICLE_GATE
    g_particle_gate_installed=1;
#else
    g_particle_gate_installed=0;
#endif
    g_model_step_installed=1;
    g_camera_step_installed=1;
    g_particle_domain_installed=1;
    g_w3d_clock_installed=1;
    g_frame_authored_installed=1;
    g_loco_correction_installed=1;
#if RA3_BOUNCE_TIMESTEP_FIX
    g_bounce_timestep_installed=1;
#else
    g_bounce_timestep_installed=0;
#endif
    return TRUE;

rollback:
    /* Best-effort rollback in reverse order. */
    if(wrote_camera && !write_memory(camera+2,camera_old,4,TRUE)) return FALSE;
    if(wrote_model && !write_memory(model+4,model_old,4,TRUE)) return FALSE;
    if(wrote_elevator && !write_memory(elevator_phase,elevator_old,sizeof(elevator_old),TRUE)) return FALSE;
    if(wrote_aeleron && !write_memory(aeleron_phase,aeleron_old,sizeof(aeleron_old),TRUE)) return FALSE;
    if(wrote_cloud && !write_memory(cloud_frame,cloud_old,sizeof(cloud_old),TRUE)) return FALSE;
    if(wrote_tracer_update && !write_memory(tracer_update,tracer_update_old,sizeof(tracer_update_old),TRUE)) return FALSE;
    if(wrote_tracer_reset && !write_memory(tracer_reset,tracer_reset_old,sizeof(tracer_reset_old),TRUE)) return FALSE;
    if(wrote_anim2d_update && !write_memory(anim2d_update,anim2d_update_old,sizeof(anim2d_update_old),TRUE)) return FALSE;
    if(wrote_anim2d_set && !write_memory(anim2d_set,anim2d_set_old,sizeof(anim2d_set_old),TRUE)) return FALSE;
    if(wrote_w3d_normal && !write_memory(w3d_normal,w3d_normal_old,sizeof(w3d_normal_old),TRUE)) return FALSE;
    if(wrote_w3d_special && !write_memory(w3d_special,w3d_special_old,sizeof(w3d_special_old),TRUE)) return FALSE;
    if(wrote_render && !write_u32(render_ptr,g_render_before,FALSE)) return FALSE;
    if(wrote_gpu_fps && !write_memory(gpu_particle+3,gpu_fps_old,4,TRUE)) return FALSE;
    if(wrote_gpu_create && !write_memory(gpu_particle_create+2,gpu_create_old,4,TRUE)) return FALSE;
#if RA3_PARTICLE_GATE
    if(wrote_particle && !write_memory(particle,particle_old,5,TRUE)) return FALSE;
#else
    (void)wrote_particle;
#endif
#if RA3_BOUNCE_TIMESTEP_FIX
    if(wrote_attach_ri && !write_memory(attach_ri,attach_ri_old,sizeof(attach_ri_old),TRUE)) return FALSE;
    if(wrote_attach_rd && !write_memory(attach_rd,attach_rd_old,sizeof(attach_rd_old),TRUE)) return FALSE;
    if(wrote_attach_rk && !write_memory(attach_rk,attach_rk_old,sizeof(attach_rk_old),TRUE)) return FALSE;
    if(wrote_attach_pi && !write_memory(attach_pi,attach_pi_old,sizeof(attach_pi_old),TRUE)) return FALSE;
    if(wrote_attach_pd && !write_memory(attach_pd,attach_pd_old,sizeof(attach_pd_old),TRUE)) return FALSE;
    if(wrote_attach_ext && !write_memory(attach_ext,attach_ext_old,sizeof(attach_ext_old),TRUE)) return FALSE;
    if(wrote_attach_pk && !write_memory(attach_pk,attach_pk_old,sizeof(attach_pk_old),TRUE)) return FALSE;
    if(wrote_bounce_ri && !write_memory(bounce_ri,bounce_ri_old,sizeof(bounce_ri_old),TRUE)) return FALSE;
    if(wrote_bounce_pi && !write_memory(bounce_pi,bounce_pi_old,sizeof(bounce_pi_old),TRUE)) return FALSE;
    if(wrote_bounce_rd && !write_memory(bounce_rd,bounce_rd_old,sizeof(bounce_rd_old),TRUE)) return FALSE;
    if(wrote_bounce_rk && !write_memory(bounce_rk,bounce_rk_old,sizeof(bounce_rk_old),TRUE)) return FALSE;
    if(wrote_bounce_pd && !write_memory(bounce_pd,bounce_pd_old,sizeof(bounce_pd_old),TRUE)) return FALSE;
    if(wrote_bounce_pk && !write_memory(bounce_pk,bounce_pk_old,sizeof(bounce_pk_old),TRUE)) return FALSE;
#endif
#if RA3_CLIENT_SLICE_FLUSH
    if(wrote_flush && !write_memory(flush,flush_old,5,TRUE)) return FALSE;
#endif
    if(wrote_interp && !write_memory(interp,interp_old,50,TRUE)) return FALSE;
    if(wrote_batch && !write_memory(batch,batch_old,41,TRUE)) return FALSE;
    return FALSE;
}

void ra3_patch_early_attach(void) {
    Ra3PeInfo pe; unsigned char *match;
    uint32_t render_abs,logic_abs; uint32_t *render_ptr,*logic_ptr;
    unsigned char *batch,*interp,*particle,*model,*camera,*client_init_mov,*client_init_fild,*gpu_particle_create,*gpu_particle;
    unsigned char *w3d_special,*w3d_normal,*anim2d_set,*anim2d_update,*tracer_reset,*tracer_update,*cloud_frame;
    unsigned char *aeleron_phase,*elevator_phase;
#if RA3_CLIENT_SLICE_FLUSH
    unsigned char *flush;
#endif
#if RA3_BOUNCE_TIMESTEP_FIX
    unsigned char *bounce_kick,*bounce_pk,*bounce_pd,*bounce_rk,*bounce_rd,*bounce_pi,*bounce_ri;
    unsigned char *attach_pk,*attach_ext,*attach_pd,*attach_pi,*attach_rk,*attach_rd,*attach_ri;
#endif

    if(!g_ra3_game_module||!valid_pe32(g_ra3_game_module,&pe)){g_early_status=RA3_EARLY_BAD_PE;return;}
    if(!find_rate_signature(g_ra3_game_module,&pe,&match)){g_early_status=RA3_EARLY_SIG_NOT_UNIQUE;return;}
    render_abs=read_u32(match+1); logic_abs=read_u32(match+9);
    render_ptr=(uint32_t*)(uintptr_t)render_abs; logic_ptr=(uint32_t*)(uintptr_t)logic_abs;
    g_render_va=render_abs; g_logic_va=logic_abs;
    if(!ptr_inside_image(g_ra3_game_module,pe.size_of_image,render_ptr,4)||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,logic_ptr,4)) {g_early_status=RA3_EARLY_BAD_POINTERS;return;}
    g_logic_before=*logic_ptr; g_render_before=*render_ptr;
    if(render_abs!=logic_abs+4||g_logic_before!=RA3_LOGIC_FPS){g_early_status=RA3_EARLY_BAD_SEMANTICS;return;}
    if(g_render_before!=RA3_RETAIL_VISUAL_FPS){g_early_status=RA3_EARLY_UNEXPECTED_RENDER;return;}
    if(!resolve_adaptive_sites(g_ra3_game_module,&pe,render_abs)){g_early_status=RA3_EARLY_SIG_NOT_UNIQUE;return;}

    batch=g_ra3_game_module+RVA_PHASE_BATCH_BLOCK;
    interp=g_ra3_game_module+RVA_PHASE_INTERP_BLOCK;
    particle=g_ra3_game_module+RVA_PARTICLE_SIM_CALL;
    model=g_ra3_game_module+RVA_MODEL_STEP_INSTRUCTION;
    camera=g_ra3_game_module+RVA_CAMERA_STEP_INSTRUCTION;
    w3d_special=g_ra3_game_module+RVA_W3D_SPECIAL_ADVANCE;
    w3d_normal=g_ra3_game_module+RVA_W3D_NORMAL_ADVANCE;
    anim2d_set=g_ra3_game_module+RVA_ANIM2D_TIMESTAMP_CALL;
    anim2d_update=g_ra3_game_module+RVA_ANIM2D_UPDATE_CALL;
    tracer_reset=g_ra3_game_module+RVA_TRACER_RESET_CALL;
    tracer_update=g_ra3_game_module+RVA_TRACER_UPDATE_CALL;
    cloud_frame=g_ra3_game_module+RVA_CLOUD_FRAME_CALL;
    aeleron_phase=g_ra3_game_module+RVA_AELERON_PHASE_LOAD;
    elevator_phase=g_ra3_game_module+RVA_ELEVATOR_PHASE_ADD;
    client_init_mov=g_ra3_game_module+RVA_CLIENT_FRAMES_MS_INIT_MOV;
    client_init_fild=g_ra3_game_module+RVA_CLIENT_FRAMES_MS_INIT_FILD;
    gpu_particle_create=g_ra3_game_module+RVA_GPU_PARTICLE_CREATE_FMUL;
    gpu_particle=g_ra3_game_module+RVA_GPU_PARTICLE_FPS_INSN;
#if RA3_CLIENT_SLICE_FLUSH
    flush=g_ra3_game_module+RVA_CLIENT_SLICE_FLUSH_GATE;
#endif
#if RA3_BOUNCE_TIMESTEP_FIX
    bounce_kick=g_ra3_game_module+RVA_BOUNCEKICK_LOAD;
    bounce_pk=g_ra3_game_module+RVA_BOUNCE_PITCH_K_MUL;
    bounce_pd=g_ra3_game_module+RVA_BOUNCE_PITCH_D_MUL;
    bounce_rk=g_ra3_game_module+RVA_BOUNCE_ROLL_K_MUL;
    bounce_rd=g_ra3_game_module+RVA_BOUNCE_ROLL_D_MUL;
    bounce_pi=g_ra3_game_module+RVA_BOUNCE_PITCH_INTEGRATE;
    bounce_ri=g_ra3_game_module+RVA_BOUNCE_ROLL_INTEGRATE;
    attach_pk=g_ra3_game_module+RVA_ATTACH_SPRING_PITCH_K_MUL;
    attach_ext=g_ra3_game_module+RVA_ATTACH_SPRING_EXTERNAL_FORCE;
    attach_pd=g_ra3_game_module+RVA_ATTACH_SPRING_PITCH_D_MUL;
    attach_pi=g_ra3_game_module+RVA_ATTACH_SPRING_PITCH_INTEGRATE;
    attach_rk=g_ra3_game_module+RVA_ATTACH_SPRING_ROLL_K_MUL;
    attach_rd=g_ra3_game_module+RVA_ATTACH_SPRING_ROLL_D_MUL;
    attach_ri=g_ra3_game_module+RVA_ATTACH_SPRING_ROLL_INTEGRATE;
#endif
    if(!ptr_inside_image(g_ra3_game_module,pe.size_of_image,batch,41)||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,interp,50)||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,particle,5)||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,model,8)||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,camera,6)||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,client_init_mov,5)||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,client_init_fild,6)||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,gpu_particle_create,6)||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,gpu_particle,7)||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,w3d_special,17)||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,w3d_normal,22)||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,anim2d_set,sizeof(g_anim2d_timestamp_expected))||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,anim2d_update,sizeof(g_frame_call_expected))||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,tracer_reset,sizeof(g_tracer_reset_expected))||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,tracer_update,sizeof(g_frame_call_expected))||
       !ptr_inside_image(g_ra3_game_module,pe.size_of_image,cloud_frame,sizeof(g_frame_call_expected))
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,aeleron_phase,sizeof(g_aeleron_phase_load_expected))
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,elevator_phase,sizeof(g_elevator_phase_add_expected))
#if RA3_CLIENT_SLICE_FLUSH
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,flush,sizeof(g_flush_expected))
#endif
#if RA3_BOUNCE_TIMESTEP_FIX
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,bounce_kick,sizeof(g_bouncekick_load_expected))
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,bounce_pk,sizeof(g_bounce_pitch_k_expected))
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,bounce_pd,sizeof(g_bounce_pitch_d_expected))
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,bounce_rk,sizeof(g_bounce_roll_k_expected))
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,bounce_rd,sizeof(g_bounce_roll_d_expected))
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,bounce_pi,sizeof(g_bounce_pitch_integrate_expected))
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,bounce_ri,sizeof(g_bounce_roll_integrate_expected))
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,attach_pk,sizeof(g_attach_pitch_k_expected))
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,attach_ext,sizeof(g_attach_external_expected))
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,attach_pd,sizeof(g_attach_pitch_d_expected))
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,attach_pi,sizeof(g_attach_pitch_integrate_expected))
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,attach_rk,sizeof(g_attach_roll_k_expected))
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,attach_rd,sizeof(g_attach_roll_d_expected))
       || !ptr_inside_image(g_ra3_game_module,pe.size_of_image,attach_ri,sizeof(g_attach_roll_integrate_expected))
#endif
       ) {g_early_status=RA3_EARLY_BAD_POINTERS;return;}

    if(!equal_bytes(batch,g_batch_expected,sizeof(g_batch_expected))||
       !validate_interp_block(interp)||!validate_model_step(model)||!validate_camera_step(camera)||
       !validate_particle_domain_init(client_init_mov,client_init_fild,render_abs)||
       !validate_gpu_particle_create(gpu_particle_create,(uint32_t)(uintptr_t)(g_ra3_game_module+RVA_CLIENT_FRAMES_MS_VALUE))||
       !validate_gpu_particle_fps(gpu_particle,render_abs)||!validate_systemic_v12_sites()) {
        g_early_status=RA3_EARLY_CODE_MISMATCH; return;
    }
    if(!validate_loco_correction_sites()) { g_early_status=RA3_EARLY_CODE_MISMATCH; return; }
#if RA3_CLIENT_SLICE_FLUSH
    if(!validate_client_slice_flush(flush)) { g_early_status=RA3_EARLY_CODE_MISMATCH; return; }
#endif
#if RA3_BOUNCE_TIMESTEP_FIX
    if(!validate_bounce_timestep_sites()) { g_early_status=RA3_EARLY_CODE_MISMATCH; return; }
#endif
#if RA3_PARTICLE_GATE
    if(!validate_particle_call(particle) || !validate_fx_authored_30_domain()) { g_early_status=RA3_EARLY_CODE_MISMATCH; return; }
#else
    (void)particle;
#endif

    if(!install_targeted_hooks(render_ptr)) {
        g_render_after=*render_ptr;
        /* If rollback succeeded the render value is back at 30. */
        g_early_status=(g_render_after==g_render_before)?RA3_EARLY_WRITE_FAILED:RA3_EARLY_ROLLBACK_FAILED;
        return;
    }
    g_render_after=*render_ptr;
    g_early_status=(g_render_after==RA3_TARGET_FPS)?RA3_EARLY_OK:RA3_EARLY_WRITE_FAILED;
}

/* Reporting runs later (first XInputGetState), outside loader lock. */
static BOOL make_sibling_path(wchar_t *out,DWORD cap,const wchar_t *name){DWORD len,i,j=0;if(!g_ra3_self_module)return FALSE;len=GetModuleFileNameW(g_ra3_self_module,out,cap);if(len==0||len>=cap)return FALSE;i=len;while(i>0&&out[i-1]!=L'\\'&&out[i-1]!=L'/')--i;if(i==0)return FALSE;while(name[j]){if(i+j+1>=cap)return FALSE;out[i+j]=name[j];++j;}out[i+j]=0;return TRUE;}
static DWORD ascii_len(const char*s){DWORD n=0;while(s&&s[n])++n;return n;}
static char *append_text(char*p,char*end,const char*s){while(*s&&p<end)*p++=*s++;return p;}
static char *append_u32_dec(char*p,char*end,uint32_t v){char t[16];unsigned n=0;if(v==0){if(p<end)*p++='0';return p;}while(v&&n<sizeof(t)){t[n++]=(char)('0'+v%10);v/=10;}while(n&&p<end)*p++=t[--n];return p;}
static char *append_u32_hex(char*p,char*end,uint32_t v){static const char h[]="0123456789ABCDEF";int s;p=append_text(p,end,"0x");for(s=28;s>=0;s-=4)if(p<end)*p++=h[(v>>s)&15];return p;}
static void log_line(const char*text){wchar_t path[MAX_PATH];HANDLE file;DWORD written;if(!text)return;OutputDebugStringA(text);OutputDebugStringA("\n");if(!make_sibling_path(path,MAX_PATH,L"fps_patch.log"))return;file=CreateFileW(path,FILE_APPEND_DATA,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);if(file==INVALID_HANDLE_VALUE)return;WriteFile(file,text,ascii_len(text),&written,NULL);WriteFile(file,"\r\n",2,&written,NULL);CloseHandle(file);}
static void log_early_ok(void){char b[360],*p=b,*e=b+sizeof(b)-1;p=append_text(p,e,"RA3 FPS patch v17-adaptive: early 60-FPS core installed; logic_fps=");p=append_u32_dec(p,e,g_logic_before);p=append_text(p,e," @ ");p=append_u32_hex(p,e,g_logic_va);p=append_text(p,e,", render_fps=");p=append_u32_dec(p,e,g_render_before);p=append_text(p,e," -> ");p=append_u32_dec(p,e,g_render_after);p=append_text(p,e," @ ");p=append_u32_hex(p,e,g_render_va);*p=0;log_line(b);log_line("RA3 FPS patch v17-adaptive: corrected 6-phase logic scheduler batching + phase interpolation");
#if RA3_CLIENT_SLICE_FLUSH
log_line("RA3 FPS patch v17-adaptive: GameLogic Object-to-Drawable queue flush limited to client-slice ends (phases 1/3/4/6 at 60 FPS)");
#else
log_line("RA3 FPS patch v17-adaptive: diagnostic build: client-slice Object-to-Drawable flush fix disabled");
#endif
log_line("RA3 FPS patch v17-adaptive: scripted-model visual step redirected from 1/30 to 1/60");
log_line("RA3 FPS patch v17-adaptive: RTS camera continuous visual step redirected from 1/30 to 1/60 (RMB drag/edge/keyboard camera timing)");
#if RA3_PARTICLE_GATE
log_line("RA3 FPS patch v17-adaptive: GPU particle create/expiry pinned to retail 30-frame domain; global client frames/ms remains live 60-FPS timing; complete FXParticleSystem simulation gated to retail 30 Hz");
#else
log_line("RA3 FPS patch v17-adaptive: GPU particle create/expiry pinned to retail 30-frame domain; global client frames/ms remains live 60-FPS timing; FXParticleSystem simulation is ungated (diagnostic only)");
#endif
#if RA3_BOUNCE_TIMESTEP_FIX
log_line("RA3 FPS patch v17-adaptive: primary BounceKick spring and secondary AttachUpdate parent-bounce pitch/roll spring use 30/60 visual timestep; BounceKick/BounceAmount impulses and logic-timed BounceTimeout are unchanged");
#else
log_line("RA3 FPS patch v17-adaptive: diagnostic build: primary BounceKick + secondary AttachUpdate parent-bounce spring timestep corrections disabled");
#endif
log_line("RA3 FPS patch v17-adaptive: Locomotor Elevator/Aeleron correction phases use 30/target visual timestep; Degree/amplitude unchanged");
{char t[180],*q=t,*te=t+sizeof(t)-1;q=append_text(q,te,"RA3 FPS patch v17-adaptive: global client frames/ms runtime bits=");q=append_u32_hex(q,te,read_u32(g_ra3_game_module+RVA_CLIENT_FRAMES_MS_VALUE));q=append_text(q,te," (expected ~0x3D75C290 after RA3 startup at 60 FPS)");*q=0;log_line(t);}log_line("RA3 FPS patch v17-adaptive: W3D fixed-point clock installed (990 retail W3D ms/sec; 16/17-ms cadence at 60 FPS)");
log_line("RA3 FPS patch v17-adaptive: frame-authored 30-Hz clock installed for Anim2D, W3DTracerDraw and CloudEffectManager");
log_line("RA3 FPS patch v17-adaptive: generic W3D/unit per-render guards remain on the real 60-Hz GameClient frame");}
static void log_early_error(LONG status){char b[192],*p=b,*e=b+sizeof(b)-1;p=append_text(p,e,"RA3 FPS patch v17-adaptive: install failed safely, status=");if(status<0){if(p<e)*p++='-';status=-status;}p=append_u32_dec(p,e,(uint32_t)status);*p=0;log_line(b);log_line("RA3 FPS patch v17-adaptive: no partial targeted hook set should remain after a write failure");}
void ra3_patch_report_checkpoint(void){LONG s=InterlockedCompareExchange(&g_report_state,1,0);if(s!=0)return;if(g_early_status==RA3_EARLY_OK)log_early_ok();else log_early_error(g_early_status);InterlockedExchange(&g_report_state,2);}
