#ifndef RA3_PATCH_H
#define RA3_PATCH_H

#include "win32_min.h"

extern HMODULE g_ra3_self_module;
extern unsigned char *g_ra3_game_module;

/* Runs from DLL_PROCESS_ATTACH, before the RA3 executable entry point.
 * Deliberately does no file I/O, LoadLibrary, sleeping, or logging. */
void ra3_patch_early_attach(void);

/* Called later from XInputGetState, outside loader lock, only to report what
 * the early attach patch already did. It does not modify game timing. */
void ra3_patch_report_checkpoint(void);

#endif
