#ifndef WIN32_MIN_H
#define WIN32_MIN_H

/* Minimal Win32 ABI declarations used by this project. This keeps the source
 * buildable with Zig/MinGW and also with a bare Clang+LLD cross toolchain. */

typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned long DWORD;
typedef signed long LONG;
typedef int BOOL;
typedef unsigned int UINT;
typedef unsigned long SIZE_T;
typedef void *HANDLE;
typedef void *HMODULE;
typedef void *HINSTANCE;
typedef void *LPVOID;
typedef const void *LPCVOID;
typedef unsigned short wchar_t;
typedef long HRESULT;

#if defined(_MSC_VER)
#  define WINAPI __stdcall
#  define DLLIMPORT __declspec(dllimport)
#  define WINASM(name) __asm__("_" #name)
#else
#  define WINAPI __attribute__((stdcall))
#  define DLLIMPORT __attribute__((dllimport))
#  define WINASM(name)
#endif

#ifndef NULL
#  define NULL ((void *)0)
#endif
#define TRUE 1
#define FALSE 0
#define MAX_PATH 260
#define DLL_PROCESS_ATTACH 1
#define FILE_APPEND_DATA 0x00000004UL
#define FILE_SHARE_READ 0x00000001UL
#define FILE_SHARE_WRITE 0x00000002UL
#define OPEN_ALWAYS 4UL
#define FILE_ATTRIBUTE_NORMAL 0x00000080UL
#define PAGE_READWRITE 0x04UL
#define PAGE_EXECUTE_READWRITE 0x40UL
#define INVALID_HANDLE_VALUE ((HANDLE)(long)-1)
#define S_FALSE ((HRESULT)1L)
#define E_FAIL ((HRESULT)0x80004005UL)
#define E_NOTIMPL ((HRESULT)0x80004001UL)
#define CLASS_E_CLASSNOTAVAILABLE ((HRESULT)0x80040111UL)

DLLIMPORT DWORD WINAPI GetModuleFileNameW(HMODULE, wchar_t *, DWORD) WINASM(GetModuleFileNameW);
DLLIMPORT void WINAPI OutputDebugStringA(const char *) WINASM(OutputDebugStringA);
DLLIMPORT HANDLE WINAPI CreateFileW(const wchar_t *, DWORD, DWORD, void *, DWORD, DWORD, HANDLE) WINASM(CreateFileW);
DLLIMPORT BOOL WINAPI WriteFile(HANDLE, const void *, DWORD, DWORD *, void *) WINASM(WriteFile);
DLLIMPORT BOOL WINAPI CloseHandle(HANDLE) WINASM(CloseHandle);
DLLIMPORT BOOL WINAPI VirtualProtect(void *, SIZE_T, DWORD, DWORD *) WINASM(VirtualProtect);
DLLIMPORT HANDLE WINAPI GetCurrentProcess(void) WINASM(GetCurrentProcess);
DLLIMPORT BOOL WINAPI FlushInstructionCache(HANDLE, LPCVOID, SIZE_T) WINASM(FlushInstructionCache);
DLLIMPORT UINT WINAPI GetPrivateProfileIntW(const wchar_t *, const wchar_t *, int, const wchar_t *) WINASM(GetPrivateProfileIntW);
DLLIMPORT LONG WINAPI InterlockedCompareExchange(volatile LONG *, LONG, LONG) WINASM(InterlockedCompareExchange);
DLLIMPORT LONG WINAPI InterlockedExchange(volatile LONG *, LONG) WINASM(InterlockedExchange);
DLLIMPORT void WINAPI Sleep(DWORD) WINASM(Sleep);
DLLIMPORT UINT WINAPI GetSystemDirectoryW(wchar_t *, UINT) WINASM(GetSystemDirectoryW);
DLLIMPORT HMODULE WINAPI LoadLibraryW(const wchar_t *) WINASM(LoadLibraryW);
DLLIMPORT void * WINAPI GetProcAddress(HMODULE, const char *) WINASM(GetProcAddress);
DLLIMPORT HMODULE WINAPI GetModuleHandleW(const wchar_t *) WINASM(GetModuleHandleW);
DLLIMPORT BOOL WINAPI DisableThreadLibraryCalls(HMODULE) WINASM(DisableThreadLibraryCalls);

#endif
