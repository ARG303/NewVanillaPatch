#include "ra3_patch.h"

/* The supplied ra3_1.12.game imports XINPUT1_3.dll by ordinal 2.
 * Disassembly of both call sites matches the two-argument XInputGetState ABI. */
typedef DWORD (WINAPI *XInputGetStateFn)(DWORD, void *);

static HMODULE g_real_xinput = NULL;
static volatile LONG g_proxy_state = 0;
static XInputGetStateFn g_real_XInputGetState = NULL;

static BOOL append_wide(wchar_t *buf, DWORD cap, const wchar_t *tail) {
    DWORD i = 0, j = 0;
    while (i < cap && buf[i]) ++i;
    if (i >= cap) return FALSE;
    while (tail[j]) {
        if (i + j + 1 >= cap) return FALSE;
        buf[i + j] = tail[j];
        ++j;
    }
    buf[i + j] = 0;
    return TRUE;
}

static BOOL make_sibling_path(wchar_t *out, DWORD cap, const wchar_t *name) {
    DWORD len, i, j = 0;
    len = GetModuleFileNameW(g_ra3_self_module, out, cap);
    if (len == 0 || len >= cap) return FALSE;
    i = len;
    while (i > 0 && out[i - 1] != L'\\' && out[i - 1] != L'/') --i;
    if (i == 0) return FALSE;
    while (name[j]) {
        if (i + j + 1 >= cap) return FALSE;
        out[i + j] = name[j];
        ++j;
    }
    out[i + j] = 0;
    return TRUE;
}

static BOOL load_real_xinput(void) {
    wchar_t path[MAX_PATH];
    LONG state = InterlockedCompareExchange(&g_proxy_state, 1, 0);
    if (state == 2) return TRUE;
    if (state == -1) return FALSE;
    if (state == 1) {
        while (InterlockedCompareExchange(&g_proxy_state, 1, 1) == 1) Sleep(0);
        return g_proxy_state == 2;
    }

    if (GetSystemDirectoryW(path, MAX_PATH) == 0 ||
        !append_wide(path, MAX_PATH, L"\\xinput1_3.dll")) {
        InterlockedExchange(&g_proxy_state, -1);
        return FALSE;
    }

    g_real_xinput = LoadLibraryW(path);
    if (!g_real_xinput && make_sibling_path(path, MAX_PATH, L"xinput1_3_original.dll")) {
        g_real_xinput = LoadLibraryW(path);
    }
    if (!g_real_xinput) {
        InterlockedExchange(&g_proxy_state, -1);
        return FALSE;
    }

    g_real_XInputGetState = (XInputGetStateFn)GetProcAddress(g_real_xinput, "XInputGetState");
    if (!g_real_XInputGetState) {
        InterlockedExchange(&g_proxy_state, -1);
        return FALSE;
    }

    InterlockedExchange(&g_proxy_state, 2);
    return TRUE;
}

DWORD WINAPI XInputGetState(DWORD user_index, void *state) {
    /* Reporting only. All game-memory modification happened in process attach. */
    ra3_patch_report_checkpoint();
    if (!load_real_xinput()) return 1167UL; /* ERROR_DEVICE_NOT_CONNECTED */
    return g_real_XInputGetState(user_index, state);
}
