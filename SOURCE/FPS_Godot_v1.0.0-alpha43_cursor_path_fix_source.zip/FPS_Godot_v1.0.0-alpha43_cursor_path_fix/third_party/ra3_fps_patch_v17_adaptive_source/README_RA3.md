# Red Alert 3 FPS patch — v17-adaptive

v17-adaptive is the hash-independent successor to v16-systemic.

The 60-FPS behavior remains based on the proven v16 patch domains, but active
patch RVAs are no longer trusted as fixed addresses from one exact
`ra3_1.12.game`. At DLL attach, the runtime:

1. locates the logic/render FPS globals from the scheduler rate signature;
2. resolves scheduler, interpolation, client-slice flush, particle, camera,
   model, W3D clock, frame-authored visual, locomotor, and bounce-spring sites
   from unique code signatures;
3. derives related sites only where the relative layout was independently
   verified across retail RA3 builds;
4. validates every resolved instruction contract before writing anything;
5. aborts safely if a required signature is missing or ambiguous.

This removes the need for an executable SHA whitelist. It was statically
validated against retail RA3 game binaries 1.1 through 1.12. Modified 1.12
executables are supported when the FPS-related routines retain the validated
instruction signatures. It intentionally does not patch arbitrary unrelated or
corrupted PE files.

The same binary can still be named `xinput1_3.dll`, but NewVanilla Patch loads
it privately as `NewVanillaFPS.dll`; the game's existing XInput file is not
required or modified.

Build with `make`. The normal output is `build-clang/xinput1_3.dll`.
