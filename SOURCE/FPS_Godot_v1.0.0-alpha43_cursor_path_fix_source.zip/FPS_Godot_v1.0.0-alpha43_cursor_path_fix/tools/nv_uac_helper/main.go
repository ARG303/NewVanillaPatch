//go:build windows

package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"
)

const (
	seeMaskNoCloseProcess = 0x00000040
	infinite              = 0xFFFFFFFF
)

type shellExecuteInfo struct {
	cbSize       uint32
	fMask        uint32
	hwnd         uintptr
	lpVerb       *uint16
	lpFile       *uint16
	lpParameters *uint16
	lpDirectory  *uint16
	nShow        int32
	hInstApp     uintptr
	lpIDList     uintptr
	lpClass      *uint16
	hkeyClass    uintptr
	dwHotKey     uint32
	hIcon        uintptr
	hProcess     syscall.Handle
}

type resultRecord struct {
	OK        bool   `json:"ok"`
	Error     string `json:"error,omitempty"`
	ExitCode  uint32 `json:"exit_code,omitempty"`
	Operation string `json:"operation,omitempty"`
}

var (
	modShell32           = syscall.NewLazyDLL("shell32.dll")
	procShellExecuteExW  = modShell32.NewProc("ShellExecuteExW")
	modKernel32          = syscall.NewLazyDLL("kernel32.dll")
	procWaitForSingleObj = modKernel32.NewProc("WaitForSingleObject")
	procGetExitCode      = modKernel32.NewProc("GetExitCodeProcess")
	procCloseHandle      = modKernel32.NewProc("CloseHandle")
)

func writeResult(path string, r resultRecord) {
	if path == "" {
		return
	}
	_ = os.MkdirAll(filepath.Dir(path), 0755)
	b, _ := json.MarshalIndent(r, "", "  ")
	_ = os.WriteFile(path, b, 0644)
}

func quoteArgs(args []string) string {
	out := make([]string, 0, len(args))
	for _, a := range args {
		out = append(out, syscall.EscapeArg(a))
	}
	return strings.Join(out, " ")
}

func relaunchElevated(args []string, resultPath, op string) int {
	exe, err := os.Executable()
	if err != nil {
		writeResult(resultPath, resultRecord{Error: err.Error(), Operation: op})
		return 20
	}
	elevatedArgs := append([]string{"--elevated"}, args...)
	verb, _ := syscall.UTF16PtrFromString("runas")
	file, _ := syscall.UTF16PtrFromString(exe)
	params, _ := syscall.UTF16PtrFromString(quoteArgs(elevatedArgs))
	dir, _ := syscall.UTF16PtrFromString(filepath.Dir(exe))
	sei := shellExecuteInfo{
		fMask:        seeMaskNoCloseProcess,
		lpVerb:       verb,
		lpFile:       file,
		lpParameters: params,
		lpDirectory:  dir,
		nShow:        0,
	}
	sei.cbSize = uint32(unsafe.Sizeof(sei))
	r1, _, callErr := procShellExecuteExW.Call(uintptr(unsafe.Pointer(&sei)))
	if r1 == 0 {
		msg := "Windows UAC was cancelled or could not start"
		if callErr != nil && callErr != syscall.Errno(0) {
			msg += ": " + callErr.Error()
		}
		writeResult(resultPath, resultRecord{Error: msg, Operation: op})
		return 21
	}
	if sei.hProcess == 0 {
		writeResult(resultPath, resultRecord{Error: "UAC helper returned no process handle", Operation: op})
		return 22
	}
	defer procCloseHandle.Call(uintptr(sei.hProcess))
	procWaitForSingleObj.Call(uintptr(sei.hProcess), infinite)
	var exitCode uint32
	ok, _, _ := procGetExitCode.Call(uintptr(sei.hProcess), uintptr(unsafe.Pointer(&exitCode)))
	if ok == 0 {
		writeResult(resultPath, resultRecord{Error: "Could not read elevated helper exit code", Operation: op})
		return 23
	}
	return int(exitCode)
}

func sha256File(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

func copyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	st, err := in.Stat()
	if err != nil {
		return err
	}
	if !st.Mode().IsRegular() {
		return errors.New("source is not a regular file")
	}
	out, err := os.OpenFile(dst, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, st.Mode().Perm())
	if err != nil {
		return err
	}
	_, copyErr := io.Copy(out, in)
	syncErr := out.Sync()
	closeErr := out.Close()
	if copyErr != nil {
		return copyErr
	}
	if syncErr != nil {
		return syncErr
	}
	return closeErr
}

func verifyExpected(path, expected string) error {
	if expected == "" {
		return nil
	}
	got, err := sha256File(path)
	if err != nil {
		return err
	}
	if !strings.EqualFold(got, expected) {
		return fmt.Errorf("SHA-256 mismatch for %s: got %s expected %s", filepath.Base(path), got, expected)
	}
	return nil
}

func ensureBackup(dst, backup string) error {
	if backup == "" {
		return nil
	}
	if filepath.Clean(backup) != filepath.Clean(dst)+strings.TrimPrefix(filepath.Clean(backup), filepath.Clean(dst)) {
		// The stricter adjacency checks below are what matter; keep this branch no-op.
	}
	if filepath.Dir(filepath.Clean(backup)) != filepath.Dir(filepath.Clean(dst)) {
		return errors.New("backup must be in the destination folder")
	}
	if _, err := os.Stat(backup); err == nil {
		return nil
	}
	if _, err := os.Stat(dst); errors.Is(err, os.ErrNotExist) {
		return nil
	}
	return copyFile(dst, backup)
}

func validateReplace(dst, backup string) error {
	if !strings.EqualFold(filepath.Ext(dst), ".SkuDef") {
		return errors.New("replace operation only permits .SkuDef destinations")
	}
	if filepath.Clean(backup) != filepath.Clean(dst+".newvanilla_backup") {
		return errors.New("unexpected SkuDef backup path")
	}
	return nil
}

func opReplace(m map[string]string) error {
	src, dst, backup := m["src"], m["dst"], m["backup"]
	if src == "" || dst == "" || backup == "" {
		return errors.New("missing replace paths")
	}
	if err := validateReplace(dst, backup); err != nil {
		return err
	}
	if err := verifyExpected(src, m["sha"]); err != nil {
		return err
	}
	if _, err := os.Stat(filepath.Dir(dst)); err != nil {
		return fmt.Errorf("destination folder unavailable: %w", err)
	}
	if err := ensureBackup(dst, backup); err != nil {
		return fmt.Errorf("backup failed: %w", err)
	}
	if err := copyFile(src, dst); err != nil {
		return fmt.Errorf("copy failed: %w", err)
	}
	return verifyExpected(dst, m["sha"])
}

func opOverlay(m map[string]string) error {
	bigSrc, bigDst := m["big-src"], m["big-dst"]
	skuSrc, skuDst := m["sku-src"], m["sku-dst"]
	bigBak, skuBak := m["big-backup"], m["sku-backup"]
	if bigSrc == "" || bigDst == "" || skuSrc == "" || skuDst == "" {
		return errors.New("missing overlay paths")
	}
	if filepath.Base(bigDst) != "ZZZ_Patch1.12.8_WinterScouts_ShaderPriority.big" {
		return errors.New("unexpected shader overlay destination")
	}
	skuBase := filepath.Base(skuDst)
	if !strings.HasPrefix(strings.ToLower(skuBase), "ra3_") || !strings.EqualFold(filepath.Ext(skuBase), ".SkuDef") {
		return errors.New("unexpected base SkuDef destination")
	}
	gameRoot := filepath.Dir(filepath.Clean(skuDst))
	expectedBigDir := filepath.Join(gameRoot, "CommunityPatch")
	if !strings.EqualFold(filepath.Clean(filepath.Dir(bigDst)), filepath.Clean(expectedBigDir)) {
		return errors.New("shader overlay BIG must be inside CommunityPatch under the base SkuDef game root")
	}
	if filepath.Clean(bigBak) != filepath.Clean(bigDst+".pre_newvanilla_backup") {
		return errors.New("unexpected overlay BIG backup path")
	}
	if filepath.Clean(skuBak) != filepath.Clean(skuDst+".newvanilla_backup") {
		return errors.New("unexpected overlay SkuDef backup path")
	}
	if err := verifyExpected(bigSrc, m["big-sha"]); err != nil {
		return err
	}
	if err := verifyExpected(skuSrc, m["sku-sha"]); err != nil {
		return err
	}
	communitySrc, communityDst := m["community-src"], m["community-dst"]
	communityBak := m["community-backup"]
	if communitySrc != "" {
		if communityDst == "" || communityBak == "" {
			return errors.New("incomplete CommunityPatch migration paths")
		}
		if !strings.EqualFold(filepath.Base(communityDst), "RA3_.SkuDef") {
			return errors.New("unexpected CommunityPatch migration destination")
		}
		if !strings.EqualFold(filepath.Clean(filepath.Dir(communityDst)), filepath.Clean(expectedBigDir)) {
			return errors.New("CommunityPatch migration SkuDef must share the shader BIG folder")
		}
		if filepath.Clean(communityBak) != filepath.Clean(communityDst+".newvanilla_backup") {
			return errors.New("unexpected CommunityPatch migration backup path")
		}
		if err := verifyExpected(communitySrc, m["community-sha"]); err != nil {
			return err
		}
	}
	if err := ensureBackup(skuDst, skuBak); err != nil {
		return fmt.Errorf("SkuDef backup failed: %w", err)
	}
	if communitySrc != "" {
		if err := ensureBackup(communityDst, communityBak); err != nil {
			return fmt.Errorf("CommunityPatch SkuDef backup failed: %w", err)
		}
	}
	if _, err := os.Stat(bigDst); err == nil {
		if err := ensureBackup(bigDst, bigBak); err != nil {
			return fmt.Errorf("BIG backup failed: %w", err)
		}
	}
	if err := copyFile(bigSrc, bigDst); err != nil {
		return fmt.Errorf("BIG copy failed: %w", err)
	}
	if err := copyFile(skuSrc, skuDst); err != nil {
		return fmt.Errorf("SkuDef copy failed: %w", err)
	}
	if communitySrc != "" {
		if err := copyFile(communitySrc, communityDst); err != nil {
			return fmt.Errorf("CommunityPatch SkuDef migration copy failed: %w", err)
		}
	}
	if err := verifyExpected(bigDst, m["big-sha"]); err != nil {
		return err
	}
	if err := verifyExpected(skuDst, m["sku-sha"]); err != nil {
		return err
	}
	if communitySrc != "" {
		return verifyExpected(communityDst, m["community-sha"])
	}
	return nil
}

func parseArgs(args []string) (bool, string, map[string]string, string, error) {
	elevated := false
	op := ""
	result := ""
	vals := map[string]string{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--elevated" {
			elevated = true
			continue
		}
		if a == "replace" || a == "overlay" {
			if op == "" {
				op = a
				continue
			}
		}
		if strings.HasPrefix(a, "--") {
			if i+1 >= len(args) {
				return false, "", nil, "", fmt.Errorf("missing value for %s", a)
			}
			key := strings.TrimPrefix(a, "--")
			i++
			vals[key] = args[i]
			if key == "result" {
				result = args[i]
			}
			continue
		}
		return false, "", nil, "", fmt.Errorf("unexpected argument: %s", a)
	}
	if op == "" {
		return false, "", nil, "", errors.New("missing operation")
	}
	return elevated, op, vals, result, nil
}

func main() {
	elevated, op, vals, resultPath, err := parseArgs(os.Args[1:])
	if err != nil {
		writeResult(resultPath, resultRecord{Error: err.Error(), Operation: op})
		os.Exit(2)
	}
	if !elevated {
		code := relaunchElevated(os.Args[1:], resultPath, op)
		os.Exit(code)
	}

	switch op {
	case "replace":
		err = opReplace(vals)
	case "overlay":
		err = opOverlay(vals)
	default:
		err = errors.New("unsupported operation")
	}
	if err != nil {
		writeResult(resultPath, resultRecord{Error: err.Error(), Operation: op})
		os.Exit(10)
	}
	writeResult(resultPath, resultRecord{OK: true, Operation: op})
}
