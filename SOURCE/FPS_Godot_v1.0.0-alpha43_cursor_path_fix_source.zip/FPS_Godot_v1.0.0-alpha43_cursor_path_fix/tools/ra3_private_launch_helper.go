//go:build windows

package main

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"
)

type result struct {
	PID        int    `json:"pid"`
	Error      string `json:"error,omitempty"`
	Mode       int    `json:"mode,omitempty"`
	PrivateExe string `json:"private_exe,omitempty"`
	XInput     string `json:"xinput,omitempty"`
}

func writeResult(path string, r result) {
	if path == "" {
		return
	}
	_ = os.MkdirAll(filepath.Dir(path), 0755)
	b, _ := json.Marshal(r)
	_ = os.WriteFile(path, b, 0644)
}

func quoteWindowsArg(arg string) string {
	if arg == "" {
		return `""`
	}
	if !strings.ContainsAny(arg, " \t\n\v\"") {
		return arg
	}
	var b strings.Builder
	b.WriteByte('"')
	slashes := 0
	for _, r := range arg {
		if r == '\\' {
			slashes++
			continue
		}
		if r == '"' {
			b.WriteString(strings.Repeat("\\", slashes*2+1))
			b.WriteRune('"')
			slashes = 0
			continue
		}
		if slashes > 0 {
			b.WriteString(strings.Repeat("\\", slashes))
			slashes = 0
		}
		b.WriteRune(r)
	}
	if slashes > 0 {
		b.WriteString(strings.Repeat("\\", slashes*2))
	}
	b.WriteByte('"')
	return b.String()
}

func buildCommandLine(exe string, args []string) string {
	parts := []string{quoteWindowsArg(exe)}
	for _, a := range args {
		parts = append(parts, quoteWindowsArg(a))
	}
	return strings.Join(parts, " ")
}

func removeJunction(path string) error {
	if _, err := os.Lstat(path); err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}
	out, err := exec.Command("cmd.exe", "/D", "/C", "rmdir", path).CombinedOutput()
	if err != nil {
		return fmt.Errorf("rmdir %s: %w (%s)", path, err, strings.TrimSpace(string(out)))
	}
	return nil
}

func ensureJunction(link, target string) error {
	absLink, err := filepath.Abs(link)
	if err != nil {
		return err
	}
	absTarget, err := filepath.Abs(target)
	if err != nil {
		return err
	}
	st, err := os.Stat(absTarget)
	if err != nil || !st.IsDir() {
		return fmt.Errorf("junction target missing: %s", absTarget)
	}
	if err := os.MkdirAll(filepath.Dir(absLink), 0755); err != nil {
		return err
	}
	if err := removeJunction(absLink); err != nil {
		return err
	}
	out, err := exec.Command("cmd.exe", "/D", "/C", "mklink", "/J", absLink, absTarget).CombinedOutput()
	if err != nil {
		return fmt.Errorf("mklink %s -> %s: %w (%s)", absLink, absTarget, err, strings.TrimSpace(string(out)))
	}
	return nil
}

func atomicCopy(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	if err := os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
		return err
	}
	tmp := dst + ".fps_tmp"
	out, err := os.Create(tmp)
	if err != nil {
		return err
	}
	_, copyErr := io.Copy(out, in)
	closeErr := out.Close()
	if copyErr != nil {
		_ = os.Remove(tmp)
		return copyErr
	}
	if closeErr != nil {
		_ = os.Remove(tmp)
		return closeErr
	}
	_ = os.Remove(dst)
	if err := os.Rename(tmp, dst); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	return nil
}

func copyBaseSkuDefs(privateRoot, gameRoot string) error {
	entries, err := os.ReadDir(gameRoot)
	if err != nil {
		return err
	}
	for _, e := range entries {
		if e.IsDir() {
			continue
		}
		n := e.Name()
		l := strings.ToLower(n)
		if !strings.HasSuffix(l, ".skudef") || strings.Contains(l, "_1.12.skudef") {
			continue
		}
		if err := atomicCopy(filepath.Join(gameRoot, n), filepath.Join(privateRoot, n)); err != nil {
			return fmt.Errorf("copy %s: %w", n, err)
		}
	}
	return nil
}

func preparePrivateRoot(privateRoot, gameRoot string) error {
	if err := os.MkdirAll(privateRoot, 0755); err != nil {
		return err
	}
	if err := ensureJunction(filepath.Join(privateRoot, "Data"), filepath.Join(gameRoot, "Data")); err != nil {
		return err
	}
	cp := filepath.Join(gameRoot, "CommunityPatch")
	cpLink := filepath.Join(privateRoot, "CommunityPatch")
	if st, err := os.Stat(cp); err == nil && st.IsDir() {
		if err := ensureJunction(cpLink, cp); err != nil {
			return err
		}
	} else {
		_ = removeJunction(cpLink)
	}
	return copyBaseSkuDefs(privateRoot, gameRoot)
}

func main() {
	var gameRoot, sourceExe, privateRoot, cleanXInput, fpsDLL, fpsINI, pidfile string
	mode := 0
	var childArgs []string
	args := os.Args[1:]
	for i := 0; i < len(args); i++ {
		need := func(name string) string {
			if i+1 >= len(args) {
				writeResult(pidfile, result{PID: -1, Error: "missing " + name + " value"})
				os.Exit(2)
			}
			i++
			return args[i]
		}
		switch args[i] {
		case "--game-root":
			gameRoot = need(args[i])
		case "--source-exe":
			sourceExe = need(args[i])
		case "--private-root":
			privateRoot = need(args[i])
		case "--clean-xinput":
			cleanXInput = need(args[i])
		case "--fps-dll":
			fpsDLL = need(args[i])
		case "--fps-ini":
			fpsINI = need(args[i])
		case "--mode":
			fmt.Sscanf(need(args[i]), "%d", &mode)
		case "--pidfile":
			pidfile = need(args[i])
		case "--":
			childArgs = append(childArgs, args[i+1:]...)
			i = len(args)
		default:
			writeResult(pidfile, result{PID: -1, Error: "unknown option: " + args[i]})
			os.Exit(2)
		}
	}
	if gameRoot == "" || sourceExe == "" || privateRoot == "" || cleanXInput == "" || pidfile == "" || (mode != 30 && mode != 60) {
		writeResult(pidfile, result{PID: -1, Error: "missing/invalid required argument"})
		os.Exit(2)
	}
	if mode == 60 && (fpsDLL == "" || fpsINI == "") {
		writeResult(pidfile, result{PID: -1, Error: "60 FPS runtime path missing"})
		os.Exit(2)
	}
	var err error
	gameRoot, err = filepath.Abs(gameRoot)
	if err != nil {
		writeResult(pidfile, result{PID: -1, Error: err.Error()})
		os.Exit(2)
	}
	sourceExe, err = filepath.Abs(sourceExe)
	if err != nil {
		writeResult(pidfile, result{PID: -1, Error: err.Error()})
		os.Exit(2)
	}
	privateRoot, err = filepath.Abs(privateRoot)
	if err != nil {
		writeResult(pidfile, result{PID: -1, Error: err.Error()})
		os.Exit(2)
	}
	cleanXInput, err = filepath.Abs(cleanXInput)
	if err != nil {
		writeResult(pidfile, result{PID: -1, Error: err.Error()})
		os.Exit(2)
	}
	if st, e := os.Stat(sourceExe); e != nil || st.IsDir() {
		writeResult(pidfile, result{PID: -1, Error: "source game executable missing"})
		os.Exit(3)
	}
	if st, e := os.Stat(cleanXInput); e != nil || st.IsDir() {
		writeResult(pidfile, result{PID: -1, Error: "clean XInput missing"})
		os.Exit(3)
	}
	if mode == 60 {
		fpsDLL, err = filepath.Abs(fpsDLL)
		if err != nil {
			writeResult(pidfile, result{PID: -1, Error: err.Error()})
			os.Exit(2)
		}
		fpsINI, err = filepath.Abs(fpsINI)
		if err != nil {
			writeResult(pidfile, result{PID: -1, Error: err.Error()})
			os.Exit(2)
		}
		if st, e := os.Stat(fpsDLL); e != nil || st.IsDir() {
			writeResult(pidfile, result{PID: -1, Error: "FPS DLL missing"})
			os.Exit(3)
		}
		if st, e := os.Stat(fpsINI); e != nil || st.IsDir() {
			writeResult(pidfile, result{PID: -1, Error: "FPS INI missing"})
			os.Exit(3)
		}
	}
	if err := preparePrivateRoot(privateRoot, gameRoot); err != nil {
		writeResult(pidfile, result{PID: -1, Error: "private root: " + err.Error()})
		os.Exit(4)
	}

	// Keep the proven alpha40/42 launch geometry: the private executable and
	// XInput proxy live directly in an isolated launch directory, while the
	// process working directory remains the real RA3 root.
	//
	// RA3's executable contains literal paths such as "data\\cursors\\%s.%s".
	// Retail installs place those loose cursor files under RA3\Data\Data\Cursors.
	// A broad launchRoot\Data -> gameRoot\Data junction was one level too shallow:
	// launchRoot\Data\Cursors resolved to gameRoot\Data\Cursors, so the cursor
	// vanished even though the game itself ran. Build only the exact compatibility
	// view needed by the private executable: launchRoot\Data\Cursors -> the real
	// cursor directory. This leaves the private SkuDef's separate Data junction
	// untouched (it still points at gameRoot\Data for BIG files).
	launchRoot := filepath.Join(privateRoot, fmt.Sprintf("launch%d_v43", mode))
	if err := os.MkdirAll(launchRoot, 0755); err != nil {
		writeResult(pidfile, result{PID: -1, Error: "create private launch dir: " + err.Error()})
		os.Exit(4)
	}
	launchData := filepath.Join(launchRoot, "Data")
	// Remove the old alpha42 broad junction if this directory name is ever reused,
	// then create a normal directory that can contain only compatibility links.
	_ = removeJunction(launchData)
	if err := os.MkdirAll(launchData, 0755); err != nil {
		writeResult(pidfile, result{PID: -1, Error: "create private Data compatibility dir: " + err.Error()})
		os.Exit(4)
	}
	cursorTarget := filepath.Join(gameRoot, "Data", "Data", "Cursors")
	if st, e := os.Stat(cursorTarget); e != nil || !st.IsDir() {
		// Some repacks flatten the loose-data directory by one level.
		alt := filepath.Join(gameRoot, "Data", "Cursors")
		if st2, e2 := os.Stat(alt); e2 == nil && st2.IsDir() {
			cursorTarget = alt
		} else {
			writeResult(pidfile, result{PID: -1, Error: "RA3 cursor directory missing (checked Data\\Data\\Cursors and Data\\Cursors)"})
			os.Exit(4)
		}
	}
	if err := ensureJunction(filepath.Join(launchData, "Cursors"), cursorTarget); err != nil {
		writeResult(pidfile, result{PID: -1, Error: "private cursor junction: " + err.Error()})
		os.Exit(4)
	}
	privateExe := filepath.Join(launchRoot, "ra3_1.12.game")
	proxyXInput := filepath.Join(launchRoot, "xinput1_3.dll")
	originalAlias := filepath.Join(launchRoot, "xinput1_3_original.dll")
	privateINI := filepath.Join(launchRoot, "NewVanillaFPS.ini")
	if err := atomicCopy(sourceExe, privateExe); err != nil {
		writeResult(pidfile, result{PID: -1, Error: "copy private game: " + err.Error()})
		os.Exit(5)
	}
	if mode == 30 {
		if err := atomicCopy(cleanXInput, proxyXInput); err != nil {
			writeResult(pidfile, result{PID: -1, Error: "copy clean XInput: " + err.Error()})
			os.Exit(5)
		}
		_ = os.Remove(originalAlias)
		_ = os.Remove(privateINI)
	} else {
		if err := atomicCopy(fpsDLL, proxyXInput); err != nil {
			writeResult(pidfile, result{PID: -1, Error: "copy FPS proxy: " + err.Error()})
			os.Exit(5)
		}
		if err := atomicCopy(cleanXInput, originalAlias); err != nil {
			writeResult(pidfile, result{PID: -1, Error: "copy original XInput alias: " + err.Error()})
			os.Exit(5)
		}
		if err := atomicCopy(fpsINI, privateINI); err != nil {
			writeResult(pidfile, result{PID: -1, Error: "copy FPS INI: " + err.Error()})
			os.Exit(5)
		}
	}

	cmdLine, err := syscall.UTF16PtrFromString(buildCommandLine(privateExe, childArgs))
	if err != nil {
		writeResult(pidfile, result{PID: -1, Error: err.Error()})
		os.Exit(6)
	}
	cwdPtr, err := syscall.UTF16PtrFromString(gameRoot)
	if err != nil {
		writeResult(pidfile, result{PID: -1, Error: err.Error()})
		os.Exit(6)
	}
	appPtr, err := syscall.UTF16PtrFromString(privateExe)
	if err != nil {
		writeResult(pidfile, result{PID: -1, Error: err.Error()})
		os.Exit(6)
	}
	var si syscall.StartupInfo
	si.Cb = uint32(unsafe.Sizeof(si))
	var pi syscall.ProcessInformation
	if err := syscall.CreateProcess(appPtr, cmdLine, nil, nil, false, 0, nil, cwdPtr, &si, &pi); err != nil {
		writeResult(pidfile, result{PID: -1, Error: "CreateProcess: " + err.Error()})
		os.Exit(7)
	}
	syscall.CloseHandle(pi.Thread)
	syscall.CloseHandle(pi.Process)
	writeResult(pidfile, result{PID: int(pi.ProcessId), Mode: mode, PrivateExe: privateExe, XInput: proxyXInput})
}
